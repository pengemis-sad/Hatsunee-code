async function events(m, { Belle }) {
  if (m.type === "interactiveResponseMessage" && m.quoted.fromMe) {
    BelleappendTextMessage(
      m,
      JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id,
      m,
    );
  }
  if (m.type === "templateButtonReplyMessage" && m.quoted.fromMe) {
    BelleappendTextMessage(m, m.msg.selectedId, m);
  }
}

module.exports = {
  events,
};
