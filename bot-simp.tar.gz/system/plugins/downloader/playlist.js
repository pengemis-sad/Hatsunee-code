// *– 乂 Tipe 2 - Code*
const yts = require("yt-search");

module.exports = {
    command: "ytsearch",
    alias: ["yts", "playlist"],
    category: ["downloader"],
    settings: {
        limit: true
    },
    description: "download youtube music dengan playlist",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        // Lakukan sesuatu di sini
        let user = m.sender;
        if (!db.list().user[user]) db.list().user[user] = {
            onplaylist: false,
            playlist: []
        }
        const arrsearch = await yts(text);
        let res = arrsearch?.videos?.filter(a => a.duration.seconds < 1201) || [];

        if (res.length == 0) return m.reply("Musik tidak di temukan");
        let results = res;

        let listText = `🎵 *Playlist: ${text}* 🎵\n\n`;
        results.forEach((item, index) => {
            listText += `${index + 1}. ${item.title}\n`;
        });
        listText += `\nBalas angka *1*, *2*, dll untuk memilih musik.`;

        // Update database
        db.list().user[user].playlist = results;
        db.list().user[user].onplaylist = true;

        m.reply(listText);
        // Hapus otomatis setelah 5 menit
        setTimeout(() => {
            if (db.list().user[user]?.onplaylist) {
                db.list().user[user].onplaylist = false;
                db.list().user[user].playlist = [];
            }
        }, 5 * 60 * 1000);
    },
};