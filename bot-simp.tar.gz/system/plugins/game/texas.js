// Simpan sebagai plugins/poker.js
const fs = require("fs");

// --- DATABASE & DATA MANAGEMENT ---
const DB_PATH = "./library/database/poker.json";
let pokerDB = {};

function loadPokerDB() {
    if (fs.existsSync(DB_PATH)) {
        try {
            pokerDB = JSON.parse(fs.readFileSync(DB_PATH));
            if (!pokerDB.users) pokerDB.users = {};
        } catch (e) {
            console.error("Gagal memuat atau parse poker_database.json:", e);
            pokerDB = {
                users: {}
            };
        }
    } else {
        pokerDB = {
            users: {}
        };
    }
}

function savePokerDB() {
    fs.writeFileSync(DB_PATH, JSON.stringify(pokerDB, null, 2));
}
loadPokerDB();

const pokerSessions = {};

// --- CARD & HAND EVALUATION LOGIC ---
const RANKS = {
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
    9: 9,
    T: 10,
    J: 11,
    Q: 12,
    K: 13,
    A: 14
};
const HAND_RANKS = {
    ROYAL_FLUSH: 10,
    STRAIGHT_FLUSH: 9,
    FOUR_OF_A_KIND: 8,
    FULL_HOUSE: 7,
    FLUSH: 6,
    STRAIGHT: 5,
    THREE_OF_A_KIND: 4,
    TWO_PAIR: 3,
    ONE_PAIR: 2,
    HIGH_CARD: 1
};
const HAND_NAMES = {
    10: "Royal Flush 👑",
    9: "Straight Flush",
    8: "Four of a Kind",
    7: "Full House",
    6: "Flush",
    5: "Straight",
    4: "Three of a Kind",
    3: "Two Pair",
    2: "One Pair",
    1: "High Card"
};

function evaluateHand(sevenCards) {
    const combinations = [];

    function getCombinations(arr, k, start = 0, current = []) {
        if (current.length === k) {
            combinations.push([...current]);
            return;
        }
        if (start === arr.length) return;
        for (let i = start; i < arr.length; i++) {
            current.push(arr[i]);
            getCombinations(arr, k, i + 1, current);
            current.pop();
        }
    }
    getCombinations(sevenCards, 5);

    let bestHand = {
        rank: 0,
        name: "",
        value: 0,
        cards: []
    };

    for (const hand of combinations) {
        const ranks = hand.map(c => RANKS[c[0]]).sort((a, b) => b - a);
        const suits = hand.map(c => c.slice(1));

        const isFlush = new Set(suits).size === 1;
        const rankCounts = ranks.reduce(
            (acc, r) => ((acc[r] = (acc[r] || 0) + 1), acc), {}
        );

        // Cek Straight, termasuk A-2-3-4-5
        const uniqueRanks = Array.from(new Set(ranks)).sort((a, b) => b - a);
        let isStraight = false;
        if (uniqueRanks.length >= 5) {
            for (let i = 0; i <= uniqueRanks.length - 5; i++) {
                if (uniqueRanks[i] - uniqueRanks[i + 4] === 4) {
                    isStraight = true;
                    break;
                }
            }
            // Cek Ace-low straight (A-2-3-4-5)
            if (
                !isStraight &&
                uniqueRanks.includes(14) &&
                uniqueRanks.includes(5) &&
                uniqueRanks.includes(4) &&
                uniqueRanks.includes(3) &&
                uniqueRanks.includes(2)
            ) {
                isStraight = true;
                // Ganti Ace (14) menjadi 1 untuk perhitungan value
                let aceLowRanks = ranks
                    .map(r => (r === 14 ? 1 : r))
                    .sort((a, b) => b - a);
                ranks.splice(0, ranks.length, ...aceLowRanks);
            }
        }

        const rankValues = Object.values(rankCounts).sort((a, b) => b - a);
        let currentRank = 0,
            handValue = 0;

        if (isStraight && isFlush) {
            currentRank =
                ranks[0] === 14 ?
                HAND_RANKS.ROYAL_FLUSH :
                HAND_RANKS.STRAIGHT_FLUSH;
            handValue = ranks[0];
        } else if (rankValues[0] === 4) {
            currentRank = HAND_RANKS.FOUR_OF_A_KIND;
            const fourRank = parseInt(
                Object.keys(rankCounts).find(k => rankCounts[k] === 4)
            );
            const kicker = parseInt(
                Object.keys(rankCounts).find(k => rankCounts[k] === 1)
            );
            handValue = fourRank * 15 + kicker;
        } else if (rankValues[0] === 3 && rankValues[1] === 2) {
            currentRank = HAND_RANKS.FULL_HOUSE;
            const threeRank = parseInt(
                Object.keys(rankCounts).find(k => rankCounts[k] === 3)
            );
            const twoRank = parseInt(
                Object.keys(rankCounts).find(k => rankCounts[k] === 2)
            );
            handValue = threeRank * 15 + twoRank;
        } else if (isFlush) {
            currentRank = HAND_RANKS.FLUSH;
            handValue = ranks.reduce(
                (sum, r, i) => sum + r * Math.pow(15, 4 - i),
                0
            );
        } else if (isStraight) {
            currentRank = HAND_RANKS.STRAIGHT;
            handValue = ranks[0];
        } else if (rankValues[0] === 3) {
            currentRank = HAND_RANKS.THREE_OF_A_KIND;
            const threeRank = parseInt(
                Object.keys(rankCounts).find(k => rankCounts[k] === 3)
            );
            const kickers = ranks.filter(r => r !== threeRank).slice(0, 2);
            handValue =
                threeRank * 225 + (kickers[0] || 0) * 15 + (kickers[1] || 0);
        } else if (rankValues[0] === 2 && rankValues[1] === 2) {
            currentRank = HAND_RANKS.TWO_PAIR;
            const pairs = Object.keys(rankCounts)
                .filter(r => rankCounts[r] === 2)
                .map(Number)
                .sort((a, b) => b - a);
            const kicker = Math.max(...ranks.filter(r => !pairs.includes(r)));
            handValue = pairs[0] * 225 + pairs[1] * 15 + kicker;
        } else if (rankValues[0] === 2) {
            currentRank = HAND_RANKS.ONE_PAIR;
            const pairRank = parseInt(
                Object.keys(rankCounts).find(k => rankCounts[k] === 2)
            );
            const kickers = ranks.filter(r => r !== pairRank).slice(0, 3);
            handValue =
                pairRank * 3375 +
                (kickers[0] || 0) * 225 +
                (kickers[1] || 0) * 15 +
                (kickers[2] || 0);
        } else {
            currentRank = HAND_RANKS.HIGH_CARD;
            handValue = ranks.reduce(
                (sum, r, i) => sum + r * Math.pow(15, 4 - i),
                0
            );
        }

        if (
            currentRank > bestHand.rank ||
            (currentRank === bestHand.rank && handValue > bestHand.value)
        ) {
            bestHand = {
                rank: currentRank,
                name: HAND_NAMES[currentRank],
                value: handValue,
                cards: hand.sort((a, b) => RANKS[b[0]] - RANKS[a[0]])
            };
        }
    }
    return bestHand;
}

// --- POKER GAME LOGIC CLASS ---
class PokerGame {
    constructor(chatId, hostId, Belle, usedPrefix, command) {
        this.chatId = chatId;
        this.Belle = Belle;
        this.usedPrefix = usedPrefix;
        this.command = command;
        this.hostId = hostId;
        this.players = [];
        this.deck = [];
        this.phase = "waiting";
        this.maxPlayers = 5;
        this.dealerIndex = -1;
        this.smallBlind = 100;
        this.bigBlind = 200;
        this.communityCards = [];
        // Game state
        this.pot = 0;
        this.currentPlayerIndex = -1;
        this.currentBet = 0;
        this.lastRaiserId = null;
        this.actionsQueue = [];
        this.isProcessing = false;
        this.timeoutId = null;
    }

    addPlayer(playerId) {
        if (this.players.length >= this.maxPlayers) {
            return `Maaf, meja sudah penuh (Maksimal ${this.maxPlayers} pemain).`;
        }
        if (this.phase !== "waiting")
            return "Game sudah dimulai, tidak bisa bergabung.";
        if (this.players.some(p => p.id === playerId))
            return "Kamu sudah di dalam game.";

        const playerData = pokerDB.users[playerId];
        if (!playerData)
            return `Kamu belum terdaftar. Ketik *${this.usedPrefix}${this.command} register <nama>* dulu.`;
        if (playerData.chips < this.bigBlind)
            return `Kamu butuh minimal ${this.bigBlind} chip untuk bermain. Chip kamu: ${playerData.chips}.`;

        this.players.push({
            id: playerId,
            name: playerData.name,
            cards: [],
            chips: playerData.chips,
            bet: 0,
            folded: false,
            isAllIn: false,
            ready: false
        });

        // Host otomatis dianggap ready
        if (playerId === this.hostId) {
            this.players.find(p => p.id === playerId).ready = true;
        }

        return `${playerData.name} telah bergabung dengan ${playerData.chips} chip.\nTotal pemain: ${this.players.length}/${this.maxPlayers}`;
    }

    setPlayerReady(playerId) {
        const player = this.players.find(p => p.id === playerId);
        if (!player) return null;
        if (player.ready) return `${player.name} sudah siap.`;

        player.ready = true;
        return `✅ *${player.name}* telah menandakan SIAP!`;
    }

    areAllPlayersReady() {
        if (this.players.length < 2) return false;
        return this.players.every(p => p.ready);
    }

    _createDeck() {
        const suits = ["♠️", "♥️", "♦️", "♣️"];
        const ranks = [
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "T",
            "J",
            "Q",
            "K",
            "A"
        ];
        let deck = [];
        for (let suit of suits) {
            for (let rank of ranks) {
                deck.push(rank + suit);
            }
        }
        return deck;
    }

    _shuffleDeck() {
        for (let i = this.deck.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.deck[i], this.deck[j]] = [this.deck[j], this.deck[i]];
        }
    }

    async startGame() {
        if (!this.areAllPlayersReady())
            return `Tidak bisa memulai, belum semua pemain siap.`;
        if (this.players.length < 2) return `Butuh minimal 2 pemain.`;

        this.phase = "pre-flop";
        this.players.forEach(p => {
            p.cards = [];
            p.bet = 0;
            p.folded = false;
            p.isAllIn = false;
            // Ambil chip dari DB utama ke sesi
            p.chips = pokerDB.users[p.id].chips;
        });

        // Filter out players with no chips before starting
        this.players = this.players.filter(p => p.chips > 0);
        if (this.players.length < 2) {
            this.phase = "waiting";
            return "Tidak cukup pemain dengan chip untuk memulai ronde baru.";
        }

        this.dealerIndex = (this.dealerIndex + 1) % this.players.length;
        const sbIndex = (this.dealerIndex + 1) % this.players.length;
        const bbIndex = (this.dealerIndex + 2) % this.players.length;
        const firstToActIndex = (this.dealerIndex + 3) % this.players.length;

        this.deck = this._createDeck();
        this._shuffleDeck();
        this.communityCards = [];
        this.pot = 0;

        // Collect Blinds
        const sbPlayer = this.players[sbIndex];
        const bbPlayer = this.players[bbIndex];
        const sbAmount = Math.min(this.smallBlind, sbPlayer.chips);
        const bbAmount = Math.min(this.bigBlind, bbPlayer.chips);

        sbPlayer.chips -= sbAmount;
        sbPlayer.bet = sbAmount;
        bbPlayer.chips -= bbAmount;
        bbPlayer.bet = bbAmount;
        if (sbPlayer.chips === 0) sbPlayer.isAllIn = true;
        if (bbPlayer.chips === 0) bbPlayer.isAllIn = true;

        this.pot = sbAmount + bbAmount;
        this.currentBet = bbAmount;
        this.lastRaiserId = bbPlayer.id;
        this.currentPlayerIndex = firstToActIndex;

        // Deal cards
        this.players.forEach(p => {
            if (!p.folded) {
                p.cards = [this.deck.pop(), this.deck.pop()];
                this.Belle.sendMessage(p.id, {
                    text: `♦️ Kartu Anda di meja grup *${
                        this.Belle.getChatById(this.chatId).name
                    }*: *${p.cards.join(", ")}*`
                });
            }
        });

        let startMsg = `*🔥 RONDE BARU DIMULAI! 🔥*\n\n`;
        startMsg += `Dealer: ${this.players[this.dealerIndex].name}\n`;
        startMsg += `${sbPlayer.name} pasang Small Blind ${sbAmount}\n`;
        startMsg += `${bbPlayer.name} pasang Big Blind ${bbAmount}\n\n`;
        startMsg += `Kartu telah dibagikan via PM.\n\n`;
        await this.Belle.sendMessage(this.chatId, {
            text: startMsg + this.renderTable()
        });
        await this._promptNextPlayer();
    }
    async handleAction(playerId, action, amount = 0) {
        this.actionsQueue.push({
            playerId,
            action,
            amount
        });
        if (this.isProcessing) return;

        this.isProcessing = true;
        while (this.actionsQueue.length > 0) {
            const currentAction = this.actionsQueue.shift();
            const player = this.players.find(
                p => p.id === currentAction.playerId
            );
            const pIndex = this.players.findIndex(
                p => p.id === currentAction.playerId
            );

            if (
                !player ||
                pIndex !== this.currentPlayerIndex ||
                player.folded ||
                player.isAllIn
            ) {
                continue;
            }
            clearTimeout(this.timeoutId);

            let actionResponse = "";
            let isValidAction = true;

            switch (currentAction.action) {
                case "fold":
                    player.folded = true;
                    actionResponse = `*${player.name}* melakukan FOLD.`;
                    break;
                case "check":
                    if (player.bet < this.currentBet) {
                        isValidAction = false;
                        actionResponse = `*${player.name}*, kamu tidak bisa check, taruhan saat ini adalah ${this.currentBet}. Gunakan \`call\` atau \`raise\`.`;
                        await this.Belle.sendMessage(this.chatId, {
                            text: actionResponse
                        });
                        break;
                    }
                    actionResponse = `*${player.name}* melakukan CHECK.`;
                    break;
                case "call":
                    const callAmount = Math.min(
                        this.currentBet - player.bet,
                        player.chips
                    );
                    player.chips -= callAmount;
                    player.bet += callAmount;
                    this.pot += callAmount;
                    if (player.chips === 0) player.isAllIn = true;
                    actionResponse =
                        `*${player.name}* melakukan CALL sejumlah ${callAmount}.` +
                        (player.isAllIn ? " (ALL-IN)" : "");
                    break;
                case "raise":
                    const totalBet = amount;
                    const minRaise =
                        this.currentBet +
                        (this.currentBet -
                            (this.lastRaiseAmount || this.bigBlind));
                    const raiseAmount = totalBet - player.bet;

                    if (totalBet < minRaise && player.chips > totalBet) {
                        isValidAction = false;
                        actionResponse = `*${player.name}*, raise minimal adalah ke ${minRaise}.`;
                    } else if (raiseAmount > player.chips) {
                        isValidAction = false;
                        actionResponse = `*${player.name}*, kamu tidak punya cukup chip untuk raise sebesar itu.`;
                    } else {
                        player.chips -= raiseAmount;
                        player.bet = totalBet;
                        this.pot += raiseAmount;
                        this.currentBet = totalBet;
                        this.lastRaiserId = player.id;
                        this.lastRaiseAmount = this.currentBet;
                        if (player.chips === 0) player.isAllIn = true;
                        actionResponse =
                            `*${player.name}* melakukan RAISE menjadi ${totalBet}.` +
                            (player.isAllIn ? " (ALL-IN)" : "");
                    }
                    if (!isValidAction)
                        await this.Belle.sendMessage(this.chatId, {
                            text: actionResponse
                        });
                    break;
                case "allin":
                    const allInAmount = player.chips;
                    player.bet += allInAmount;
                    this.pot += allInAmount;
                    player.chips = 0;
                    player.isAllIn = true;
                    if (player.bet > this.currentBet) {
                        this.currentBet = player.bet;
                        this.lastRaiserId = player.id;
                    }
                    actionResponse = `*${player.name}* mempertaruhkan segalanya, ALL-IN dengan ${allInAmount}!`;
                    break;
            }

            if (isValidAction) {
                await this.Belle.sendMessage(this.chatId, {
                    text: actionResponse
                });

                const activePlayers = this.players.filter(p => !p.folded);
                if (activePlayers.length === 1) {
                    await this._awardPotToWinner(activePlayers[0]);
                    this.isProcessing = false;
                    return;
                }

                await this._nextTurn();
            }
        }
        this.isProcessing = false;
        if (this.phase !== "waiting" && this.phase !== "showdown") {
            await this._promptNextPlayer();
        }
    }

    async _nextTurn() {
        const activePlayersWhoCanBet = this.players.filter(
            p => !p.folded && !p.isAllIn
        );
        if (activePlayersWhoCanBet.length <= 1) {
            const actingPlayer = this.players[this.currentPlayerIndex];
            if (
                actingPlayer.bet === this.currentBet ||
                (actingPlayer.isAllIn && activePlayersWhoCanBet.length === 1)
            ) {
                await this._progressRound();
                return;
            }
        }

        let nextIndex = this.currentPlayerIndex;
        do {
            nextIndex = (nextIndex + 1) % this.players.length;
        } while (
            this.players[nextIndex].folded ||
            this.players[nextIndex].isAllIn
        );

        this.currentPlayerIndex = nextIndex;

        // Check if betting round is over
        if (this.players[this.currentPlayerIndex].id === this.lastRaiserId) {
            await this._progressRound();
        }
    }

    async _promptNextPlayer() {
        await this.Belle.sendMessage(this.chatId, {
            text: this.renderTable() + "\n" + this._getCurrentTurnMessage()
        });
    }

    _getCurrentTurnMessage() {
        if (this.phase === "waiting" || this.phase === "showdown") return "";
        const currentPlayer = this.players[this.currentPlayerIndex];
        let msg = `Giliran *${currentPlayer.name}*.\n`;
        msg += `Chip: ${currentPlayer.chips} | Bet Ronde Ini: ${currentPlayer.bet}\n`;
        let actions = [];
        if (currentPlayer.bet < this.currentBet) {
            actions.push(`\`${this.usedPrefix}${this.command} call\``);
            actions.push(
                `\`${this.usedPrefix}${this.command} raise <jumlah>\``
            );
        } else {
            actions.push(`\`${this.usedPrefix}${this.command} check\``);
            actions.push(
                `\`${this.usedPrefix}${this.command} raise <jumlah>\``
            );
        }
        actions.push(`\`${this.usedPrefix}${this.command} fold\``);
        actions.push(`\`${this.usedPrefix}${this.command} allin\``);
        msg += "Aksi: " + actions.join(" | ");
        return msg;
    }

    async _progressRound() {
        let roundMessage = "";
        this.players.forEach(p => {
            this.pot += p.bet;
            p.bet = 0;
        });
        this.currentBet = 0;
        this.lastRaiserId = null;
        this.lastRaiseAmount = 0;

        let firstToAct = (this.dealerIndex + 1) % this.players.length;
        while (
            this.players[firstToAct].folded ||
            this.players[firstToAct].isAllIn
        ) {
            firstToAct = (firstToAct + 1) % this.players.length;
        }
        this.currentPlayerIndex = firstToAct;

        switch (this.phase) {
            case "pre-flop":
                this.phase = "flop";
                this.communityCards.push(
                    this.deck.pop(),
                    this.deck.pop(),
                    this.deck.pop()
                );
                roundMessage = `*--- FLOP ---*\n[ ${this.communityCards.join(
                    " "
                )} ]`;
                break;
            case "flop":
                this.phase = "turn";
                this.communityCards.push(this.deck.pop());
                roundMessage = `*--- TURN ---*\n[ ${this.communityCards.join(
                    " "
                )} ]`;
                break;
            case "turn":
                this.phase = "river";
                this.communityCards.push(this.deck.pop());
                roundMessage = `*--- RIVER ---*\n[ ${this.communityCards.join(
                    " "
                )} ]`;
                break;
            case "river":
                await this._showdown();
                return;
        }

        await this.Belle.sendMessage(this.chatId, {
            text: roundMessage
        });
        await this._promptNextPlayer();
    }

    async _showdown() {
        this.phase = "showdown";
        let showdownMsg = `*--- SHOWDOWN ---*\nMeja: [ ${this.communityCards.join(
            " "
        )} ]\n\n`;

        const contenders = this.players.filter(p => !p.folded);
        if (contenders.length === 0) return;
        if (contenders.length === 1) {
            await this._awardPotToWinner(contenders[0]);
            return;
        }

        let results = [];
        for (const player of contenders) {
            const handResult = evaluateHand([
                ...player.cards,
                ...this.communityCards
            ]);
            results.push({
                ...player,
                hand: handResult
            });
            showdownMsg += `*${player.name}*: ${player.cards.join(" ")} -> *${
                handResult.name
            }*\n`;
        }

        results.sort((a, b) => {
            if (b.hand.rank !== a.hand.rank) return b.hand.rank - a.hand.rank;
            return b.hand.value - a.hand.value;
        });

        const winner = results[0];

        await this.Belle.sendMessage(this.chatId, {
            text: showdownMsg + "\n" + this.renderTable(true)
        });
        await this._awardPotToWinner(winner);
    }

    async _awardPotToWinner(winner) {
        const winAmount = this.pot;
        pokerDB.users[winner.id].chips += winAmount;
        pokerDB.users[winner.id].wins =
            (pokerDB.users[winner.id].wins || 0) + 1;

        this.players.forEach(p => {
            if (p.id !== winner.id) {
                pokerDB.users[p.id].losses =
                    (pokerDB.users[p.id].losses || 0) + 1;
            }
        });
        savePokerDB();

        this.phase = "waiting";
        this.players.forEach(p => (p.ready = false)); // Reset ready status

        await this.Belle.sendMessage(this.chatId, {
            text: `🎉 *${winner.name} memenangkan pot sebesar ${winAmount}!* 🎉\n\nGame selesai. Host bisa ketik *${this.usedPrefix}${this.command} deal* untuk ronde baru atau *${this.usedPrefix}${this.command} end* untuk mengakhiri.`
        });
    }

    renderTable(showdown = false) {
        let table = "```\n";
        table += "╔══════════════════════════════════╗\n";
        table += `║ Pot: ${this.pot}`.padEnd(35) + "║\n";
        table += "║──────────────────────────────────║\n";
        const communityStr =
            `║ Meja: ${this.communityCards.join(" ")}`.padEnd(35) + "║\n";
        table += communityStr;
        table += "╠══════════════════════════════════╣\n";

        this.players.forEach((p, index) => {
            let playerLine = `║ ${
                index === this.currentPlayerIndex &&
                this.phase !== "showdown" &&
                this.phase !== "waiting"
                    ? "▶"
                    : " "
            }`;
            playerLine += ` ${p.name.substring(0, 10)}`.padEnd(12);
            playerLine += `| Chip: ${p.chips}`.padEnd(13);

            if (p.folded) {
                playerLine += "| FOLDED";
            } else if (showdown) {
                playerLine += `| ${p.cards.join(" ")}`;
            } else {
                playerLine += `| Bet: ${p.bet}`;
            }

            table += playerLine.padEnd(35) + "║\n";
        });

        table += "╚══════════════════════════════════╝\n";
        table += "```";
        return table;
    }
}

// --- MAIN PLUGIN HANDLER ---
module.exports = {
    command: "poker",
    alias: ["texasholdem", "texas"],
    category: ["game"],
    description: "game texasholdem",
    settings: {
        loading: false
    },
    async run(m, {
        text,
        Belle,
        command,
        usedPrefix
    }) {
        const chatId = m.cht;
        const senderId = m.sender;

        const body = m.body || "";
        let args, subCommand;

        if (body.startsWith(usedPrefix + command + " _")) {
            const internalArgs = body
                .slice((usedPrefix + command).length)
                .trim()
                .split(/\s+/);
            subCommand = internalArgs.shift().toLowerCase();
            args = internalArgs;
        } else {
            args = text.trim().split(/\s+/);
            subCommand = (args.shift() || "").toLowerCase();
        }

        let session = pokerSessions[chatId];

        switch (subCommand) {
            case "register":
                const newName = args.join(" ");
                if (pokerDB.users[senderId])
                    return m.reply("Kamu sudah terdaftar.");
                if (!newName)
                    return m.reply(
                        `Format salah. Gunakan: *${m.usedPrefix}${m.command} register <nama kamu>*`
                    );
                if (newName.length > 15)
                    return m.reply(
                        "Nama terlalu panjang, maksimal 15 karakter."
                    );

                pokerDB.users[senderId] = {
                    name: newName,
                    chips: 100000,
                    wins: 0,
                    losses: 0
                };
                savePokerDB();
                return m.reply(
                    `✅ Registrasi Sultan Berhasil, *${newName}*! Kamu mendapatkan modal awal *100.000 chip*.`
                );

            case "help":
            case "bantuan":
            case "tutorial":
                const helpText = `
*🃏 TUTORIAL & BANTUAN POKER 🃏*

Selamat datang di Poker Texas Hold'em! Berikut panduan lengkapnya.

*1. PENDAFTARAN & DASAR*
- \`${m.usedPrefix}${m.command} register <nama>\`
  Daftar untuk pertama kali dan dapatkan *100.000 chip* gratis!
- \`${m.usedPrefix}${m.command} wallet\`
  Cek sisa chip, nama, dan statistik menang/kalah kamu.
- \`${m.usedPrefix}${m.command} top\`
  Lihat peringkat pemain terkaya.

*2. CARA MEMULAI GAME*
\`Langkah 1:\` Satu orang (host) membuat meja:
  \`${m.usedPrefix}${m.command} start\`
\`Langkah 2:\` Pemain lain bergabung ke meja:
  \`${m.usedPrefix}${m.command} join\`
\`Langkah 3:\` Host memulai pengecekan kesiapan:
  \`${m.usedPrefix}${m.command} ready\`
  (Semua pemain harus mengklik nama mereka di daftar yang muncul)
\`Langkah 4:\` Setelah semua siap, host memulai ronde:
  \`${m.usedPrefix}${m.command} deal\`

*3. ATURAN MAIN (ALUR PERMAINAN)*
Game berjalan otomatis setelah dimulai.
- *Blinds*: Setiap awal ronde, 2 pemain akan memasang taruhan wajib (Small & Big Blind).
- *Pre-Flop*: Babak taruhan pertama setelah kartu dibagikan.
- *Flop*: 3 kartu komunitas dibuka di meja. Babak taruhan kedua.
- *Turn*: Kartu ke-4 dibuka. Babak taruhan ketiga.
- *River*: Kartu ke-5 (terakhir) dibuka. Babak taruhan final.
- *Showdown*: Semua pemain yang tersisa membuka kartu. Pemenang ditentukan.

*4. PERINTAH AKSI (SAAT GILIRANMU)*
- \`${m.usedPrefix}${m.command} fold\`
  Menyerah dari ronde ini.
- \`${m.usedPrefix}${m.command} check\`
  Lanjut tanpa bertaruh (hanya jika belum ada yang menaikkan taruhan).
- \`${m.usedPrefix}${m.command} call\`
  Ikut dengan jumlah taruhan tertinggi saat ini.
- \`${m.usedPrefix}${m.command} raise <jumlah>\`
  Menaikkan taruhan. Contoh: \`${m.usedPrefix}${m.command} raise 500\`
- \`${m.usedPrefix}${m.command} allin\`
  Mempertaruhkan semua sisa chip kamu.

*5. PERINGKAT KOMBINASI KARTU*
(Dari terkuat hingga terlemah)
👑 *Royal Flush* (A-K-Q-J-T, satu jenis)
🌟 *Straight Flush* (5 kartu berurutan, satu jenis)
 JJJJ *Four of a Kind* (4 kartu dengan rank sama)
🏠 *Full House* (3 kartu sama + 2 kartu sama)
💎 *Flush* (5 kartu dengan jenis sama)
📈 *Straight* (5 kartu berurutan)
 JJJ *Three of a Kind* (3 kartu dengan rank sama)
 QQJJ *Two Pair* (Dua pasang kartu)
 JJ *One Pair* (Sepasang kartu)
 A *High Card* (Jika tidak ada kombinasi di atas)

Semoga berhasil di meja hijau! ♠️♥️♦️♣️`;
                return m.reply(helpText);

            case "start":
            case "create":
                if (session)
                    return m.reply(
                        `Game sudah ada. Gunakan *${m.usedPrefix}${m.command} join*`
                    );
                session = new PokerGame(
                    chatId,
                    senderId,
                    Belle,
                    usedPrefix,
                    command
                );
                pokerSessions[chatId] = session;
                const startJoinResult = session.addPlayer(senderId);
                return m.reply(
                    `♠️♥️ Meja Poker telah dibuat! ♦️♣️\n${startJoinResult}\n\nPemain lain (maks ${
                        session.maxPlayers - 1
                    }) bisa bergabung dengan:\n*${m.usedPrefix}${
                        m.command
                    } join*`
                );

            case "join":
                if (!session)
                    return m.reply(
                        `Tidak ada game. Mulai dengan *${m.usedPrefix}${m.command} start*`
                    );
                const joinResult = session.addPlayer(senderId);
                const replyMsg = await m.reply(joinResult);
                if (session.players.length === session.maxPlayers) {
                    await Belle.sendMessage(
                        m.cht, {
                            text: "Meja sudah penuh! Memulai Ready Check otomatis..."
                        }, {
                            quoted: replyMsg
                        }
                    );
                    const host = pokerDB.users[session.hostId].name;
                    await m.reply(
                        `Host (${host}), silakan ketik *${m.usedPrefix}${m.command} ready* untuk memulai pengecekan.`
                    );
                }
                return;

            case "ready":
                if (!session) return m.reply("Tidak ada game.");
                if (senderId !== session.hostId)
                    return m.reply("Hanya host yang bisa memulai ready check.");
                if (session.phase !== "waiting")
                    return m.reply("Game sudah dimulai.");
                if (session.players.length < 2)
                    return m.reply("Butuh minimal 2 pemain.");

                const sections = [{
                    title: "DAFTAR PEMAIN",
                    rows: session.players.map(p => ({
                        title: `${p.name}`,
                        rowId: `${m.usedPrefix}${m.command} _readyconfirm ${p.id}`,
                        description: p.ready ? "✅ SIAP" : "❌ BELUM SIAP"
                    }))
                }];

                const listMessage = {
                    text: `*READY CHECK DIMULAI*\n\nSilakan klik nama Anda di bawah ini untuk konfirmasi.`,
                    footer: `Pemain: ${session.players.length}/${session.maxPlayers}`,
                    title: "♠️♥️ POKER READY CHECK ♦️♣️",
                    buttonText: "PILIH NAMA ANDA",
                    sections
                };
                return Belle.sendMessage(chatId, listMessage);

            case "_readyconfirm":
                if (!session) return;
                const playerIdToReady = args[0];
                if (senderId !== playerIdToReady)
                    return m.reply("Hei, jangan klik tombol orang lain ya! 😉");

                const readyResult = session.setPlayerReady(senderId);
                await m.reply(readyResult);

                if (session.areAllPlayersReady()) {
                    const hostName = pokerDB.users[session.hostId].name;
                    await Belle.sendMessage(chatId, {
                        text: `🎉 *Semua pemain sudah siap!*\n\nHost (${hostName}) sekarang bisa memulai permainan dengan mengetik:\n*${m.usedPrefix}${m.command} deal*`
                    });
                }
                return;

            case "deal":
                if (!session) return m.reply("Tidak ada game.");
                if (senderId !== session.hostId)
                    return m.reply("Hanya host yang bisa memulai game.");
                const startResult = await session.startGame();
                if (typeof startResult === "string") m.reply(startResult);
                return;

            case "end":
            case "stop":
                if (!session)
                    return m.reply("Tidak ada game untuk dihentikan.");
                if (senderId !== session.hostId)
                    return m.reply("Hanya host yang bisa menghentikan game.");
                delete pokerSessions[chatId];
                return m.reply("Sesi game poker telah dihentikan oleh host.");

            case "call":
            case "check":
            case "fold":
            case "allin":
                if (!session) return;
                await session.handleAction(senderId, subCommand);
                break;

            case "raise":
                if (!session) return;
                const amount = parseInt(args[0]);
                if (isNaN(amount) || amount <= 0)
                    return m.reply(
                        `Jumlah raise tidak valid. Contoh: \`${m.usedPrefix}${m.command} raise 500\``
                    );
                await session.handleAction(senderId, subCommand, amount);
                break;

            default:
                const defaultMenu = `Perintah tidak dikenal. Ketik *${m.usedPrefix}${m.command} help* untuk melihat daftar perintah lengkap.`;
                return m.reply(defaultMenu);
        }
    }
};