/*
 * Nama Fitur : Removebg + Upscale
 * Type : Plugin Esm
 * Sumber : https://whatsapp.com/channel/0029Vb6Zs8yEgGfRQWWWp639
 * Sumber skrep : https://whatsapp.com/channel/0029VakezCJDp2Q68C61RH2C
 * Author : ZenzzXD
 */

const axios = require('axios');
const FormData = require('form-data');

async function uploadUguu(buffer, filename = 'image.png') {
    const form = new FormData()
    form.append('files[]', buffer, {
        filename
    })

    const {
        data
    } = await axios.post('https://uguu.se/upload.php', form, {
        headers: form.getHeaders()
    })

    const url = data?.files?.[0]?.url
    if (!url) throw new Error('uplot ke uguu gagal')
    return url
}

async function removeBackgroundMosyne(buffer) {
    const imageUrl = await uploadUguu(buffer)
    const headers = {
        accept: 'application/json, text/plain, */*',
        'content-type': 'application/json',
        origin: 'https://mosyne.ai',
        referer: 'https://mosyne.ai/ai/remove-bg',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64)'
    }

    const user_id = 'user_test'
    const {
        data
    } = await axios.post(
        'https://mosyne.ai/api/remove_background', {
            image: imageUrl,
            user_id
        }, {
            headers
        }
    )

    if (!data.id) throw new Error('Gagal dapat ID remove bg')
    const checkPayload = {
        id: data.id,
        type: 'remove_background',
        user_id
    }

    for (let i = 0; i < 30; i++) {
        await new Promise(res => setTimeout(res, 2000))
        const {
            data: status
        } = await axios.post(
            'https://mosyne.ai/api/status',
            checkPayload, {
                headers
            }
        )

        if (status.status === 'COMPLETED' && status.image) return status.image
        if (status.status === 'FAILED') throw new Error('Gagal hapus background')
    }

    throw new Error('timeout proses hapus begron')
}

async function upscaleMosyne(url) {
    const headers = {
        accept: 'application/json, text/plain, */*',
        'content-type': 'application/json',
        origin: 'https://mosyne.ai',
        referer: 'https://mosyne.ai/ai/upscaling',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64)'
    }

    const user_id = 'user_test'
    const {
        data
    } = await axios.post(
        'https://mosyne.ai/api/upscale', {
            image: url,
            user_id
        }, {
            headers
        }
    )

    if (!data.id) throw new Error('ggal dapat id upscale')
    const checkPayload = {
        id: data.id,
        type: 'upscale',
        user_id
    }

    for (let i = 0; i < 30; i++) {
        await new Promise(res => setTimeout(res, 2000))
        const {
            data: status
        } = await axios.post(
            'https://mosyne.ai/api/status',
            checkPayload, {
                headers
            }
        )

        if (status.status === 'COMPLETED' && status.image) return status.image
        if (status.status === 'FAILED') throw new Error('upscale gagal')
    }

    throw new Error('timeout proses upscale')
}

module.exports = {
    command: "removebg",
    alias: ["rmbg", "rbg", "removebackground"],
    category: ["tools"],
    settings: {},
    description: "",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        try {
            const q = m.quoted ? m.quoted : m
            const mime = (q.msg || q).mimetype || ''

            if (!mime.startsWith('image/')) {
                return m.reply('silahkan kirim atau reply gambar untuk dihapus background nya')
            }

            await m.reply('bentar gusy lagi kua hapus background nya')

            const media = await q.download()

            const removedBgUrl = await removeBackgroundMosyne(media)

            await m.reply('lagi di hd kan gusy sabarr')

            const upscaledUrl = await upscaleMosyne(removedBgUrl)

            await m.reply({
                image: {
                    url: upscaledUrl
                },
                mimetype: 'image/png',
                caption: config.messages.success
            }, {
                quoted: m
            })

        } catch (e) {
            console.error(e)
            m.reply(`Eror kak: ${e?.message || e || 'gk tau'}`)
        };
    }
}