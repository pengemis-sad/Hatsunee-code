class RedOrBlack {
    constructor() {
        this.deck = this.createDeck();
    }
    createDeck() {
        let suits = ['Hearts', 'Diamonds', 'Clubs', 'Spades'];
        let ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace'];
        return suits.flatMap(suit => ranks.map(rank => ({
            suit,
            rank
        })));
    }
    shuffle() {
        for (let i = this.deck.length - 1; i > 0; i--) {
            let j = Math.floor(Math.random() * (i + 1));
            [this.deck[i], this.deck[j]] = [this.deck[j], this.deck[i]];
        }
    }
    draw(choice, bet) {
        this.shuffle();
        let card = this.deck.pop();
        let isRed = card.suit === 'Hearts' || card.suit === 'Diamonds';
        let win = (choice === 'red' && isRed) || (choice === 'black' && !isRed);
        return {
            card,
            result: win ? 'win' : 'lose',
            payout: win ? bet * 2 : 0
        }
    }
}

module.exports = {
    command: "redorblack",
    alias: ["rb"],
    category: ["game"],
    async run(m, {
        Belle,
        text
    }) {
        let args = text.trim().split(" ");
        let aturan = `*🃏 Cara Main & Aturan Red or Black:*
1. Pilih warna (red/hitam) dan pasang taruhan.
2. Jika kartu yang diambil warnanya sama dengan pilihanmu, kamu menang dan dapat 2x taruhan.
Contoh: .rb 1000 red`;
        if (args.length < 2) return m.reply(aturan);

        let bet = parseInt(args);
        let choice = args[args.length - 1].toLowerCase();
        let user = db.list().user[m.sender];
        if (!user?.register) return m.reply("Anda belum terdaftar!");
        if (isNaN(bet) || bet < 1) return m.reply('Jumlah taruhan tidak valid!');
        if (!['red', 'black'].includes(choice)) return m.reply('Pilih warna red atau black!');
        let game = new RedOrBlack();
        let result;

        // Cek ngutang lebih dari 1 juta
        if (user.rpg.money < bet && Math.abs(user.rpg.money - bet) > 1000000) {
            // Paksa kartu jadi warna kebalikan pilihan user
            let suit = choice === 'red' ?
                (Math.random() < 0.5 ? 'Clubs' : 'Spades') :
                (Math.random() < 0.5 ? 'Hearts' : 'Diamonds');
            let ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace'];
            let rank = ranks[Math.floor(Math.random() * ranks.length)];
            let card = {
                suit,
                rank
            };
            result = {
                card,
                result: 'lose',
                payout: 0
            };
        } else {
            result = game.draw(choice, bet);
        }

        let suitSymbol = {
            Hearts: '♥️',
            Diamonds: '♦️',
            Clubs: '♣️',
            Spades: '♠️'
        };
        let dealerChoice = choice === 'red' ? 'black' : 'red';

        // Tampilkan kartu dengan emoji, walau kalah karena utang
        let cardDisplay = result.card.rank && result.card.suit ?
            `${result.card.rank} of ${suitSymbol[result.card.suit] || result.card.suit}` :
            'Kartu tidak tersedia';

        user.rpg.money += result.payout - bet;

        let msg = `*🃏 • R E D   o r   B L A C K •*

╭───┈ •
│ *Card:*
│ \`${cardDisplay}\`
├───┈ •
│ *Your Choice:*
│ \`${choice}\`
│ *Dealer's Color:*
│ \`${dealerChoice}\`
╰───┈ •

*Bet:*
${result.result === 'win' ? '+' : '-'}\`${bet}\` uang

*Payout:*
\`${result.payout}\`

${result.result === 'win' ? '> *YOU WIN! 🎉*' : '> *DEALER WIN! 😔*'}
`;
        m.reply(msg);
    }
};