const {
    loadImage,
    createCanvas
} = require('canvas');

module.exports = {
    command: "qcimg",
    alias: ["imgquote", "quoteimage"],
    category: ["tools"],
    settings: {},
    description: "",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        // Lakukan sesuatu di sini
        const waifuImages = [
            'https://files.catbox.moe/3rtvux.jpg',
            'https://files.catbox.moe/lo2ykk.jpg',
            'https://files.catbox.moe/v5ks10.jpg',
            'https://files.catbox.moe/oawwlm.jpg',
            'https://files.catbox.moe/jgf5gm.jpg',
            'https://files.catbox.moe/c2kief.jpg'
        ];

        let [topText, bottomText, thirdText] = text.split("|").map(v => v?.trim());

        if (!topText) return m.reply(`⚠ Teks tidak boleh kosong!\n\nContoh:\n.qcimg pesan|nama|©RenitaMarybelle`);

        function wrapText(ctx, text, maxWidth) {
            const words = text.split(' ');
            let lines = [],
                line = '';
            for (const word of words) {
                const testLine = line + word + ' ';
                if (ctx.measureText(testLine).width > maxWidth && line) {
                    lines.push(line);
                    line = word + ' ';
                } else {
                    line = testLine;
                }
            }
            lines.push(line);
            return lines;
        }

        function drawAutoText(ctx, text, maxWidth, x, y, fontStyle, minFont = 12, baseFont = 34, lineHeight = 1.2) {
            let size = baseFont;
            ctx.font = `${fontStyle} ${size}px Arial`;
            let lines = wrapText(ctx, text, maxWidth);
            while (lines.some(line => ctx.measureText(line).width > maxWidth) && size > minFont) {
                size -= 2;
                ctx.font = `${fontStyle} ${size}px Arial`;
                lines = wrapText(ctx, text, maxWidth);
            }
            lines.forEach((line, i) => ctx.fillText(line, x, y + i * size * lineHeight));
            return {
                lines,
                size
            };
        }

        try {
            const {
                createCanvas,
                loadImage
            } = require('canvas');
            const randomBg = waifuImages[Math.floor(Math.random() * waifuImages.length)];
            const bg = await loadImage(randomBg);
            const canvas = createCanvas(bg.width, bg.height);
            const ctx = canvas.getContext('2d');

            ctx.drawImage(bg, 0, 0);
            ctx.fillStyle = '#ffffff';
            ctx.textAlign = 'left';

            // Top text
            const TOP_Y = 188,
                BOTTOM_OFFSET = 10,
                THIRD_OFFSET = 6;
            const top = drawAutoText(ctx, topText, 600, 450, TOP_Y, 'bold', 14, 34);

            // Bottom text otomatis turun dari bawah topText
            let bottomY = TOP_Y + (top.lines.length * top.size * 1.2) + BOTTOM_OFFSET;
            let bottom = {
                lines: [],
                size: 0
            };
            if (bottomText) {
                bottom = drawAutoText(ctx, bottomText, 600, 450, bottomY, 'italic bold', 10, 20);
            }

            // Third text (copyright/tag) otomatis turun dari bawah bottomText
            if (thirdText) {
                let thirdY = bottomY + (bottom.lines.length * bottom.size * 1.2) + THIRD_OFFSET;
                drawAutoText(ctx, thirdText, 600, 450, thirdY, 'normal', 8, 16);
            }

            const buffer = canvas.toBuffer();
            await m.reply({
                image: buffer,
                caption: "🖼️ *Gambarnya udah jadi guys!*"
            }, {
                quoted: m
            });

        } catch (e) {
            console.error(e);
            m.reply(`❌ Gagal membuat gambar:\n${e.message.toString()}`);
        }
    }
}