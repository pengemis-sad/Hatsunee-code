const axios = require('axios');

const models = {
    'ChatGPT-4o': 'chatgpt-4o',
    'ChatGPT-4o Mini': 'chatgpt-4o-mini',
    'Claude 3 Opus': 'claude-3-opus',
    'Claude 3.5 Sonnet': 'claude-3-sonnet',
    'Llama 3': 'llama-3',
    'Llama 3.1 (Pro)': 'llama-3-pro',
    'Perplexity AI': 'perplexity-ai',
    'Mistral Large': 'mistral-large',
    'Gemini 1.5 Pro': 'gemini-1.5-pro'
}

async function askAI(prompt, modelKey = 'Claude 3.5 Sonnet') {
    const model = models[modelKey]
    if (!model) return `Model "${modelKey}" ga ada.`

    try {
        const {
            data
        } = await axios.post('https://whatsthebigdata.com/api/ask-ai/', {
            message: prompt,
            model,
            history: []
        }, {
            headers: {
                'content-type': 'application/json',
                'origin': 'https://whatsthebigdata.com',
                'referer': 'https://whatsthebigdata.com/ai-chat/',
                'user-agent': 'Mozilla/5.0'
            }
        })

        if (data?.text) return {
            author: '控 GrizLy nyasar—',
            result: {
                model: data.model,
                text: `${data.text}`
            }
        }; //`*Model:* ${modelKey}\n*Jawaban:*\n${data.text}`
        return 'gtw ga ada respon.'
    } catch (e) {
        return `emror: ${e.response?.status === 400 ? 'Prompt dilarang sma model.' : e.message}`
    }
}

module.exports = askAI;