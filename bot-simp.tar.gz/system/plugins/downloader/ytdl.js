const axios = require('axios');
const yts = require('yt-search');

async function ytdl(URL, form) {
    const headers = {
        "accept": "*/*",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": "\"Android\"",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "cross-site",
        "Referer": "https://id.ytmp3.mobi/",
        "Referrer-Policy": "strict-origin-when-cross-origin"
    }

    const initial = await axios.get(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {
        headers
    });
    const format = form;
    const init = initial.data;

    const id = URL.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
    if (!id) throw "Link YouTube tidak valid.";

    const convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
    const converts = await axios.get(convertURL, {
        headers
    });
    const convert = converts.data;

    let info = {};
    for (let i = 0; i < 3; i++) {
        const j = await axios.get(convert.progressURL, {
            headers
        });
        info = j.data;
        if (info.progress == 3) break;
        await new Promise(res => setTimeout(res, 1000)); // kasih delay
    }

    return {
        url: convert.downloadURL,
        title: info.title,
        thumb: `https://img.youtube.com/vi/${id}/maxresdefault.jpg'`
    };
}

module.exports = {
    command: "ytdl",
    alias: ["youtubedl", "ytmp4", "ytmp3", "yt", "youtubedownload"],
    category: ["downloader"],
    settings: {
        limit: false
    },
    description: "Cari dan unduh audio dari YouTube / YouTubeの音声をダウンロード",
    async run(m, {
        Belle,
        Func,
        text,
        command,
        config
    }) {
        try {
            m.react("🔎");
            const args = text.split(" ");
            let option, urlna;
            if (m.command === "ytmp4" && m.text) {
                option = "mp4";
                urlna = m.text;
            } else if (m.command === "ytmp3" && m.text) {
                option = "mp3";
                urlna = m.text;
            } else {
                [option, urlna] = args;
            }
            if (!urlna || !option) {
                m.react('❓');
                return m.reply(
                    `╭──[❌ *Masukkan Input yang Valid / 有効な入力を入力してください* ]
᎒⊸ Masukkan link YouTube yang valid.
᎒⊸ Contoh: *${m.prefix}${m.command}  mp3/mp4 https://youtu.be/abc123* atau *.ytmp3 https://youtu.be/abc123*
╰────────────•`
                );
            }
            let hasil = await ytdl(urlna, option);
            let detail = (await yts(urlna)).all[0]

            if (!hasil || !hasil.url) {
                return m.reply(
                    `╭──[❌ *Not Found / 見つかりません* ]
᎒⊸ Tidak ada video ditemukan dengan url *"${urlna}"*. Coba gunakan link lain!
╰────────────•`
                );
            }

            m.react("📥");
            let cap = `╭──[🎵 *YouTube音声ダウンローダー* ]
᎒⊸ *Judul*: ${detail.title}
᎒⊸ *Channel*: ${detail.author.name}
᎒⊸ *Durasi*: ${detail.timestamp}
᎒⊸ *Views*: ${detail.views.toLocaleString()}
᎒⊸ *Request From*: 光 ${m.pushName || '控 グリズリー'}
╰────────────•

📝 *Catatan / メモ:*
> ᎒⊸ silakan jika terdapat error bisa lapor ke developer/pemilik
🔗 *Link Video*: ${detail.url}
> © 光 RenitaBelle— / グリズリー`;

            switch (option) {
                case "mp4":
                    return m.reply({
                        video: {
                            url: hasil.url
                        },
                        caption: cap
                    });
                case "mp3":
                    const ress = (await axios.get(hasil.url, {
                        responseType: 'arraybuffer'
                    })).data
                    let buff = Buffer.from(ress);
                    let bufferna = await Func.toMp3(buff);

                    return Belle.sendMessage(
                        m.cht, {
                            audio: bufferna,
                            mimetype: "audio/mpeg",
                            fileName: detail.title + ".mp3",
                            contextInfo: {
                                externalAdReply: {
                                    sourceUrl: detail.url,
                                    mediaUrl: detail.url,
                                    mediaType: 2,
                                    title: detail.title,
                                    body: config.name,
                                    thumbnailUrl: detail.thumbnail
                                }
                            }
                        }, {
                            quoted: m
                        }
                    );
                default:
                    m.react('❓')
                    return m.reply("Format tidak dikenali. Gunakan mp3 atau mp4.");
            }
        } catch (e) {
            console.error(e);
            m.reply(e.toString());
        }
    },
};