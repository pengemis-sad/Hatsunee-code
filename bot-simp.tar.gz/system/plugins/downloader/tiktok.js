const axios = require("axios");
const cheerio = require("cheerio");

async function savetik(url) {
    try {
        const res = await axios.post('https://savetik.co/api/ajaxSearch?q=' + url);
        const $ = cheerio.load(res.data.data);
        let title = $('.clearfix h3').text();
        let thumb = $('.image-tik img').attr('src');
        let link = [];
        $('a[onclick="showAd()"]').each((i, el) => {
            const elAbay = $(el).attr('href');
            link.push(elAbay);
        });
        return {
            title,
            thumb,
            link
        };
    } catch (e) {
        throw e;
    }
}

module.exports = {
    command: "tiktok",
    alias: ["ttdl", "tt"],
    category: ["downloader"],
    description: "Download video TikTok tanpa watermark",
    async run(m, {
        Belle,
        text
    }) {
        if (!text) throw "Kirim link TikTok yang mau didownload!";
        try {
            let data = await savetik(text);
            if (!data.link.length) throw "Gagal ambil link download!";
            await Belle.sendMessage(m.cht, {
                video: {
                    url: data.link[0]
                },
                contextInfo: {
                    mentionedJid: [m.sender]
                }
            });
            await Belle.sendMessage(m.cht, {
                audio: {
                    url: data.link[2]
                },
                mimetype: 'audio/mpeg',
                contextInfo: {
                    mentionedJid: [m.sender]
                }
            });
            m.reply(`*${data.title}*`);
        } catch (e) {
            m.reply("Gagal download. Link salah atau server error.");
        }
    },
};