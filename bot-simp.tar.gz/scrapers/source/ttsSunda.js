const axios = require('axios');
const cheerio = require('cheerio');

const ttsSunda = async teks => {
const html = await axios.get('https://crikk.com/text-to-speech');
const $ = cheerio.load(html.data)
const xsrf = html.headers['set-cookie'][0].split(';')[0];
const session = html.headers['set-cookie'][1].split(';')[0];
const token = $('#generate-voice input').attr('value');
const req = {
_token: token,
languages: 'Sundanese',
voice: 'su-ID-TutiNeural',
text: teks
};
const res = await axios.post('https://crikk.com/app/generate-audio-frontend', req, {
headers: {
'Cookie': `${xsrf}; ${session}`
}
});
let buffer = Buffer.from(res.data.audio.split(',')[1], 'base64');
  return {
message: res.data.message,
author: '控 GrizLy nyasar—',
audio: buffer
};
}

module.exports = ttsSunda;