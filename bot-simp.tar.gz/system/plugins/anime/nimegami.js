/*
- Plugins Nimegami (klo ada error fix sndiri ya, buru² bikinnya)
- Source: https://whatsapp.com/channel/0029Vb1NWzkCRs1ifTWBb13u
- Source Scrape: https://whatsapp.com/channel/0029Vb2WECv9xVJaXVi46y2m/374
*/
const axios = require('axios');
const cheerio = require('cheerio');
//import axios from 'axios';
//import cheerio from 'cheerio';

const BASE_URL = 'https://nimegami.id/';

function cleanText(text) {
    return text ? text.trim().replace(/\s+/g, ' ') : '';
}

function cleanUrl(url) {
    if (!url) return url;
    let decoded;
    try {
        decoded = decodeURIComponent(url);
    } catch {
        decoded = url;
    }
    decoded = decoded.trim().replace(/[\r\n\t]/g, '');
    try {
        return encodeURI(decoded);
    } catch {
        return decoded;
    }
}

module.exports = {
    command: "nimegami",
    alias: ["nm", "nime"],
    category: ["anime", "downloader"],
    settings: {},
    description: "nimegami search, detail & download anime",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        store,
        text,
        config
    }) {
        // Lakukan sesuatu di sini
        const helpMessage = `
Gunakan salah satu perintah berikut:
- *.nimegami search <judul>* untuk mencari anime di Nimegami.
- *.nimegami detail <url>* untuk melihat detail anime.
- *.nimegami download <url> [kualitas]* untuk mendapatkan semua link download (default: 360p).

Contoh penggunaan:
1. *.nimegami search Jujutsu Kaisen* untuk mencari anime.
2. *.nimegami detail https://nimegami.id/xxxxxx* untuk detail anime.
3. *.nimegami download https://nimegami.id/xxxxxx* untuk semua link download (default 360p).
4. *.nimegami download https://nimegami.id/xxxxxx 720p* untuk semua link download dengan kualitas 720p.
  `;

        try {
            const args = text.split(" ")
            if (!args[0]) {
                await Belle.sendMessage(m.cht, {
                    text: helpMessage
                }, {
                    quoted: m
                });
                return;
            }

            const type = args[0].toLowerCase();

            switch (type) {
                case 'search':
                case 'src':
                    if (!args[1]) {
                        await Belle.sendMessage(m.cht, {
                            text: helpMessage
                        }, {
                            quoted: m
                        });
                        return;
                    }
                    const query = args.slice(1).join(' ');
                    const searchResults = await nimegamiSearch(query);
                    if (searchResults.length === 0) throw 'Tidak ada hasil ditemukan untuk kata kunci tersebut.';
                    let searchText = `Hasil pencarian untuk "${query}":\n\n`;
                    searchText += searchResults.map((item, index) =>
                        `${index + 1}. *${item.title}*\n` +
                        `   URL: ${item.link}\n` +
                        `   Thumbnail: ${item.thumb || 'Tidak ada thumbnail'}\n` +
                        `   Status: ${item.status || 'N/A'}\n` +
                        `   Tipe: ${item.tipe || 'N/A'}\n` +
                        `   Jumlah Episode: ${item.jumlahEps || 'N/A'}\n` +
                        `   Rating: ${item.rating || 'N/A'}\n` +
                        `   Langkah berikutnya: !.nimegami detail/download ${item.link}`
                    ).join('\n\n');
                    await Belle.sendMessage(m.cht, {
                        text: searchText,
                        contextInfo: {
                            externalAdReply: {
                                title: 'Pencarian Nimegami',
                                body: `Hasil untuk "${query}"`,
                                thumbnailUrl: searchResults[0]?.thumb || 'https://nimegami.id/wp-content/uploads/2023/10/default.jpg',
                                sourceUrl: BASE_URL,
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        }
                    }, {
                        quoted: m
                    });
                    break;

                case 'detail':
                case 'dtl':
                    if (!args[1]) {
                        await Belle.sendMessage(m.cht, {
                            text: helpMessage
                        }, {
                            quoted: m
                        });
                        return;
                    }
                    const detailResult = await nimegamiDetail(args[1]);
                    if (!detailResult || detailResult.length === 0) throw 'Gagal mendapatkan detail anime.';
                    const detail = detailResult[0];
                    let detailText = `*${detail.judul}*\n\n` +
                        //`• Thumbnail: ${detail.thumb || 'N/A'}\n` +
                        `• Author: ${detail.author || 'N/A'}\n` +
                        `• Durasi Episode: ${detail.durasiEps || 'N/A'}\n` +
                        `• Rating: ${detail.rating || 'N/A'}\n` +
                        `• Studio: ${detail.studio || 'N/A'}\n` +
                        `• Genre: ${detail.genre.join(', ') || 'N/A'}\n` +
                        `• Musim: ${detail.musim || 'N/A'}\n` +
                        `• Tipe: ${detail.tipe || 'N/A'}\n` +
                        `• Subtitle: ${detail.subtitle || 'N/A'}\n` +
                        `• Credit: ${detail.credit || 'N/A'}\n` +
                        `• Sinopsis: ${detail.sinopsis || 'N/A'}\n`;
                    await Belle.sendMessage(m.cht, {
                        image: {
                            url: detail.thumb
                        },
                        caption: detailText,
                        contextInfo: {
                            externalAdReply: {
                                title: detail.judul,
                                body: `Detail anime`,
                                thumbnailUrl: detail.thumb || 'https://nimegami.id/wp-content/uploads/2023/10/default.jpg',
                                sourceUrl: args[1],
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        }
                    }, {
                        quoted: m
                    });
                    break;

                case 'download':
                case 'dl':
                    if (!args[1]) {
                        await Belle.sendMessage(m.cht, {
                            text: helpMessage
                        }, {
                            quoted: m
                        });
                        return;
                    }
                    const episode = args[2] || '1';
                    const kualitasFilter = args[3] || '360p';
                    const downloadResults = await nimegamiDownload(args[1], episode, kualitasFilter);
                    if (downloadResults.length === 0) throw `Tidak ada link download ditemukan untuk kualitas ${kualitasFilter}.`;
                    let downloadText = `*Link Download*\n\n`;
                    for (const result of downloadResults) {
                        downloadText += `• Episode: ${result.eps}\n` +
                            `• Kualitas: ${result.kualitas}\n` +
                            `• Link:\n${result.link.map((l, i) => `  ${i + 1}. ${l}`).join('\n')}\n\n`;
                        for (const link of result.link) {
                            if (link.includes('berkasdrive.com/')) {
                                const driveInfo = await berkasDriveLink(link);
                                if (driveInfo) {

                                    /*
                                    downloadText += `• Detail Google Drive:\n` +
                                                    `  Filename: ${driveInfo.filename || 'N/A'}\n` +
                                                    `  Server 1: ${driveInfo.server1 || 'N/A'}\n` +
                                                    `  Server 2: ${driveInfo.server2 || 'N/A'}\n` +
                                                    `  Server 3: ${driveInfo.server3 || 'N/A'}\n\n`;
                                                    **/
                                }
                            }
                        }
                    }
                    await Belle.sendMessage(m.cht, {
                        text: downloadText,
                        contextInfo: {
                            externalAdReply: {
                                title: 'Link Download Nimegami',
                                body: `Kualitas: ${kualitasFilter}`,
                                thumbnailUrl: 'https://nimegami.id/wp-content/uploads/2023/10/default.jpg',
                                sourceUrl: args[1],
                                mediaType: 1,
                                renderLargerThumbnail: false
                            }
                        }
                    }, {
                        quoted: m
                    });
                    break;

                case 'video':
                case 'vid':
                case 'berkasdrive':
                    if (!args[1]) return m.reply('mana link berkasdrive nya??');
                    const link = await berkasDriveLink(args[1]);
                    const res = link[0];
                    const response = res.server1;
                    await Belle.sendMessage(m.cht, {
                        video: {
                            url: response
                        },
                        caption: 'ini kak.. jangan lupa bintang 5 nya ya...\n> _kunjungi juga website aslinya supaya semangat upload animenya :)_'
                    }, {
                        quoted: m
                    });
                    break;

                default:
                    await Belle.sendMessage(m.cht, {
                        text: helpMessage
                    }, {
                        quoted: m
                    });
                    return;
            }
        } catch (error) {
            console.error(error);
            await Belle.sendMessage(m.cht, {
                text: error.message.toString() || 'Terjadi kesalahan yang tidak diketahui.'
            }, {
                quoted: m
            });
        }
    },
};


async function nimegamiSearch(query) {
    const {
        data
    } = await axios.get(`${BASE_URL}?s=${encodeURIComponent(query)}&post_type=post`, {
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });
    const $ = cheerio.load(data);
    const result = [];
    $('.archive-a article').each((i, el) => {
        const thumb = cleanUrl($(el).find('.attachment-medium').attr('src'));
        const title = cleanText($(el).find('h2').text());
        const status = cleanText($(el).find('.term_tag-a a').text());
        const tipe = cleanText($(el).find('.terms_tag').text());
        const jumlahEps = cleanText($(el).find('.eps-archive').text());
        const rating = cleanText($(el).find('.rating-archive').text()) || 'Belum ada rating';
        const link = cleanUrl($(el).find('h2 a').attr('href'));
        if (title && link) {
            result.push({
                thumb,
                title,
                status,
                tipe,
                jumlahEps,
                rating,
                link
            });
        }
    });
    return result;
}

async function nimegamiDetail(url) {
    const {
        data
    } = await axios.get(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });
    const $ = cheerio.load(data);
    return $('article.single').map((i, el) => {
        const genre = [];
        $(el).find('.info2 table tbody tr .info_a a').each((i, ul) => {
            const g = cleanText($(ul).text());
            if (g) genre.push(g);
        });
        return {
            thumb: cleanUrl($(el).find('.coverthumbnail a').attr('href')),
            judul: cleanText($(el).find('.info2 table tbody tr td').eq(1).text()),
            author: cleanText($(el).find('.info2 table tbody tr td').eq(3).text()),
            durasiEps: cleanText($(el).find('.info2 table tbody tr td').eq(5).text()),
            rating: cleanText($(el).find('.info2 table tbody tr td').eq(7).text()),
            studio: cleanText($(el).find('.info2 table tbody tr td').eq(9).text()),
            genre,
            musim: cleanText($(el).find('.info2 table tbody tr td').eq(13).text()),
            tipe: cleanText($(el).find('.info2 table tbody tr td').eq(15).text()),
            subtitle: cleanText($(el).find('.info2 table tbody tr td').eq(19).text()),
            credit: cleanText($(el).find('.info2 table tbody tr td').eq(21).text()),
            sinopsis: cleanText($(el).find('#Sinopsis p').eq(0).text())
        };
    }).get();
}


async function nimegamiDownload(url, eps, kualitasFilter) {
    const {
        data
    } = await axios.get(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });
    const $ = cheerio.load(data);
    const result = [];
    $('.download h4').each((i, el) => {
        const episode = cleanText($(el).text());
        if (!eps || episode.includes(eps)) {
            $(el).next('ul').find('li').each((j, li) => {
                const quality = cleanText($(li).find('strong').text());
                if (!kualitasFilter || quality === kualitasFilter) {
                    const links = [];
                    $(li).find('a').each((k, a) => {
                        const link = cleanUrl($(a).attr('href'));
                        if (link) links.push(link);
                    });
                    if (links.length > 0) {
                        result.push({
                            eps: episode,
                            kualitas: quality,
                            link: links
                        });
                    }
                }
            });
        }
    });
    return result;
}

async function berkasDriveLink(url) {
    try {
        const {
            data
        } = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });
        const $ = cheerio.load(data);
        let result = [];
        result.push({
            filename: cleanText($('.header_content h1').text()) || 'N/A',
            server1: $('#ini_download_biasa').attr('href') || 'N/A',
            server2: $('#ini_download_cf').attr('href') || 'N/A',
            server3: $('#ini_download_bunny').attr('href') || 'N/A'
        });
        return result;
    } catch {
        return null;
    }
}