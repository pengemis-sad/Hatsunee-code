const axios = require('axios');
const fs = require('fs');
const PATH = './memorybelle-ai.json';

let sessionHistory = fs.existsSync(PATH) ? JSON.parse(fs.readFileSync(PATH)) : {}

function saveHistory() {
    fs.writeFileSync(PATH, JSON.stringify(sessionHistory, null, 2))
}

module.exports = {
    command: "askai",
    alias: ["ai", "claude", "claude-haiku", "gpt", "gpt3", "gemini", "mistral", "command"],
    category: ["ai"],
    settings: {},
    description: "",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        // Lakukan sesuatu di sini
        if (!text) return m.reply('❌ Masukkan pertanyaan untuk AI.\nContoh:.askai siapa presiden indonesia sekarang')

        const models = {
            'claude': 'claude-3-opus',
            'gpt': 'gpt-4-0125-preview',
            'gpt3': 'gpt-3.5-turbo',
            'gemini': 'gemini-1.5-pro',
            'mistral': 'mistral-large',
            'command': 'command-r-plus'
        }

        let [firstWord, ...rest] = text.split(' ')
        let modelKey = firstWord.toLowerCase()
        let prompt = m.text

        if (models[m.command]) {
            // Jika perintah == model, auto set modelKey & prompt kosong/berikutnya
            modelKey = m.command
            prompt = rest.join(' ') || 'Perkenalkan dirimu'
        }

        if (models[modelKey]) {
            prompt = rest.join(' ')
        } else {
            modelKey = 'claude'
            prompt = text
        }

        const model = models[modelKey]
        const sender = m.sender
        if (!sessionHistory[sender]) sessionHistory[sender] = []
        // Simpan chat user ke history, tapi exclude di param API
        sessionHistory[sender].push({
            role: 'user',
            content: prompt
        })
        if (sessionHistory[sender].length > 10) sessionHistory[sender] = sessionHistory[sender].slice(-10)

        try {
            const {
                data
            } = await axios.post('https://whatsthebigdata.com/api/ask-ai/', {
                message: prompt,
                model,
                history: sessionHistory[sender].slice(0, -1)
            }, {
                headers: {
                    'content-type': 'application/json',
                    'origin': 'https://whatsthebigdata.com',
                    'referer': 'https://whatsthebigdata.com/ai-chat/',
                    'user-agent': 'Mozilla/5.0'
                }
            })

            if (data?.text) {
                sessionHistory[sender].push({
                    role: 'assistant',
                    content: data.text
                })
                if (sessionHistory[sender].length > 10) sessionHistory[sender] = sessionHistory[sender].slice(-10)
                saveHistory()
                return m.reply(`*Model:* ${data.model}\n\n${data.text}`)
            } else {
                return m.reply('❌ Tidak ada respon dari AI.')
            }
        } catch (e) {
            return m.reply(`❌ Error: ${e.response?.status === 400? 'Prompt dilarang oleh model.': e.message}`)
        }
    },
}