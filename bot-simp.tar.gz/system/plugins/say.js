class Commands {
    constructor() {
        this.command = ["say"];
        this.alias = ['say'];
        this.description = ["Toold kirim text"];
        this.loading = false;
    }

    async run(m, {
        Belle,
        Scraper,
        text
    }) {
        if (!m.text) return m.reply("Masukan Textnya!");
        let say = await Scraper.ttsSunda(m.text);
        m.reply({
            audio: say.audio,
            mimetype: 'audio/mpeg',
            ptt: true
        });
    }
}

module.exports = new Commands();