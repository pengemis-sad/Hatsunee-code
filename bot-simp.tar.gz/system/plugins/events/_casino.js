const {
    exec
} = require("child_process");
const util = require("node:util");

async function events(
    m, {
        Belle,
        config,
        text,
        plugins,
        Func,
        Scraper,
        Uploader,
        store,
        isAdmin,
        botAdmin,
        isPrems,
        isBanned,
    },
) {
    // Handler untuk menerima tantangan
    if (
        m.command &&
        m.command.toLowerCase() === 'terima' &&
        Belle.casino &&
        Belle.casino[m.sender]
    ) {
        let casinoCmd = '';
        try {
            let {
                playerA,
                bet,
                chat
            } = Belle.casino[m.sender];
            if (!db.list().user[playerA] || !db.list().user[m.sender]) {
                throw 'User belum terdaftar!';
            }
            let poinA = Math.floor(Math.random() * 101);
            let poinB = Math.floor(Math.random() * 101);
            if (poinA > poinB) {
                db.list().user[playerA].rpg.money += bet;
                db.list().user[m.sender].rpg.money -= bet;
                casinoCmd = `🎉 @${playerA.split('@')[0]} MENANG! (${poinA} vs ${poinB})\n+${bet} uang`;
            } else if (poinA < poinB) {
                db.list().user[playerA].rpg.money -= bet;
                db.list().user[m.sender].rpg.money += bet;
                casinoCmd = `🎉 @${m.sender.split('@')[0]} MENANG! (${poinA} vs ${poinB})\n+${bet} uang`;
            } else {
                casinoCmd = `SERIIII! (${poinA} vs ${poinB})\nUang kembali.`;
            }
            delete Belle.casino[m.sender];
        } catch (e) {
            casinoCmd = e;
        }
        new Promise((resolve, reject) => {
                try {
                    resolve(casinoCmd);
                } catch (err) {
                    reject(err);
                }
            })
            .then(res => m.reply(res, {
                mentions: [Belle.casino?.[m.sender]?.playerA, m.sender]
            }))
            .catch(err => m.reply(String(err)));
    }
}

module.exports = {
    events,
};