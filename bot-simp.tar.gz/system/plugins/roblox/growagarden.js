module.exports = {
    command: "growagarden",
    alias: [
        "gagstock", "growgarden", "ggstock", "growgardenstok",
        "stokgrowgarden", "ggstok"
    ],
    category: ["roblox"],
    settings: {},
    description: "cek grow a garden item ceunah",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        try {
            const axios = require('axios');
            const tough = require('tough-cookie');
            const {
                wrapper
            } = require('axios-cookiejar-support');

            const base = 'https://www.gamersberg.com';
            const pageUrl = '/grow-a-garden/stock';
            const stockUrl = '/api/grow-a-garden/stock';

            const headers = {
                'user-agent': 'Postify/1.0.0',
                'x-requested-with': 'idm.internet.download.manager.plus',
                'accept-language': 'id,en;q=0.9',
                referer: 'https://www.gamersberg.com/sw.js',
                'sec-check-site': 'same-origin',
                'sec-check-mode': 'cors',
                'sec-check-dest': 'empty'
            };

            const jar = new tough.CookieJar();
            const client = wrapper(axios.create({
                jar
            }));

            // Ambil data page/session dulu
            await client.get(base + pageUrl, {
                headers: {
                    'user-agent': headers['user-agent'],
                    referer: headers.referer
                }
            });

            const {
                data
            } = await client.get(base + stockUrl, {
                headers,
                timeout: 15000
            });

            const payload = data?.data?.[0];
            if (!payload) return m.reply('Data Grow a Garden Stock-nya kosong gusy🥀');

            const {
                playerName,
                userId,
                updateNumber,
                timestamp,
                weather,
                seeds,
                gear,
                eggs,
                cosmetic
            } = payload;

            // Fix: tampilkan info "weather" dengan properti jika object
            let weatherStr = typeof weather === "object" ? (weather.type || weather.name || JSON.stringify(weather)) : weather;

            // Gabung item jadi list seperti contoh
            const listItems = (obj, type) =>
                Object.entries(obj).map(([name, qty]) =>
                    `- *${name}* (${type}): ${qty}`);

            const eggItems = eggs.map(({
                    name,
                    quantity
                }) =>
                `- *${name}* (eggs): ${quantity}`);

            // Contoh: hanya tampilkan 10 item awal (kaya sample)
            const daftarItems = [...listItems(seeds, 'seeds'), ...listItems(gear, 'gear'), ...listItems(cosmetic, 'cosmetics'), ...eggItems].slice(0, 16).join('\n');

            // Format hasil persis seperti contoh user
            const textRespon =
                `🌼 *Grow A Garden Stock*\n\n` +
                `👤 *Player:* ${playerName}\n` +
                `🧩 *User ID:* ${userId}\n` +
                `📦 *Update:* ${updateNumber}\n` +
                `🌤️ *Weather:* ${weatherStr}\n` +
                `🕒 *Last Sync:* ${timestamp}\n\n` +
                `*— Daftar Item —*\n${daftarItems}\n\n` +
                `Powered by ${config.name}`;

            m.reply(textRespon);

        } catch (e) {
            console.error(e);
            m.reply('❌ Gagal mengambil data Grow a Garden.');
        }
    },
};