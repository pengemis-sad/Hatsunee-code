const moment = require("moment-timezone");
const pkg = require(process.cwd() + "/package.json");
const axios = require("axios");
const fs = require("node:fs");
const path = require("node:path");

module.exports = {
    command: "menu",
    alias: ["menu", "help"],
    category: ["main"],
    description: "Menampilkan menu bot",
    loading: true,
    async run(m, {
        Belle,
        plugins,
        config,
        Func,
        text
    }) {
        let data = fs.readFileSync(process.cwd() + "/system/whatsapp/whatsapp.js", "utf8");
        let casePattern = /case\s+"([^"]+)"/g;
        let matches = data.match(casePattern);
        if (!matches) return m.reply("Tidak ada case yang ditemukan.");
        matches = matches.map((match) => match.replace(/case\s+"([^"]+)"/, "$1"));
        let menu = {};
        plugins.forEach((item) => {
            if (item.category && item.command && item.alias) {
                item.category.forEach((cat) => {
                    if (!menu[cat]) {
                        menu[cat] = {
                            command: [],
                        };
                    }
                    menu[cat].command.push({
                        name: item.command,
                        alias: item.alias,
                        description: item.description,
                        settings: item.settings,
                    });
                });
            }
        });
        let cmd = 0;
        let alias = 0;
        let pp = await Belle
            .profilePictureUrl(m.sender, "image")
            .catch((e) => "https://files.catbox.moe/8getyg.jpg");
        Object.values(menu).forEach((category) => {
            cmd += category.command.length;
            category.command.forEach((command) => {
                alias += command.alias.length;
            });
        });
        let premium = db.list().user[m.sender].premium.status;
        let limit = db.list().user[m.sender].limit;

        const header = `  _🖤Hi there, Adorable souls!🖤_
    _✂️I'm Renita Marybelle, Cursed puppet and puppeteer from project:LIVIUM Chapter:02, and please get ready for your daily dose so smile🌹🖤🥰✂️._\n
   やっほー、${m.sender.split('@')[0]} さん！レニタだよ〜☺️\n私はWhatsAppボットのアシスタントで、いくつかのインターネット機能をお手伝いします！\n
   Hai ${m.pushName} namaku Renita〜😊 Aku adalah asisten bot WhatsApp 
yang akan membantumu dengan beberapa fitur internet yang disediakan!
👋Salam kenal~
─────────────────────────\n`;


        const footer = `
    
> 💬 *Fitur Limit*: 🥈
> 💎 *Fitur Premium*: 🥇
─────────────────────────
`;

        if (text === "all") {
            let caption = `${header} 
「利用者」*Info Pengguna*:
> - 「名」Nama: ${m.pushName}
> - 「タグ」Tag: @${m.sender.split("@")[0]}
> - 「状態」Status: ${m.isOwner ? "Developer" : premium ? "Premium" : "Gratis"}
> - 「制限」Limit: ${m.isOwner ? "Unlimited" : limit}

「機械」*Info Bot*:
> - 「名」Nama: ${pkg.name}
> - 「版」Versi: v${pkg.version}
> - 「稼働」Waktu Aktif: ${Func.toDate(process.uptime() * 1000)}
> - 「接頭」Prefix: [ ${m.prefix} ]
> - 「命令」Total perintah: ${cmd + alias + matches.length}

「時間」*Info Waktu*:
> - 「時」${moment().tz("Asia/Jakarta").format("HH:mm:ss")} WIB
> - 「時」${moment().tz("Asia/Makassar").format("HH:mm:ss")} WITA
> - 「時」${moment().tz("Asia/Jayapura").format("HH:mm:ss")} WIT
> - 「日」Hari: ${["Minggu（日）","Senin（月）","Selasa（火）", "Rabu（水）", "Kamis（木）", "Jumat（金）", "Sabtu（土）"][moment().tz("Asia/Jakarta").day()]}
> - 「日」Tanggal: ${moment().tz("Asia/Jakarta").date()} ${["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"][moment().tz("Asia/Jakarta").month()]} ${moment().tz("Asia/Jakarta").year()}

「機能」*Menu – OTHER (uncategorized)*  
${matches.map((a, i) => `> *(${i + 1})* ${m.prefix + a}`).join("\n")}

─────────────────────────`;

            Object.entries(menu).forEach(([tag, commands]) => {
                caption += `\n🛠️ *Menu – ${tag.toUpperCase()}* 
${commands.command.map((command, index) => `> *(${index + 1})* ${m.prefix + command.name} ${command.settings?.premium ? "🥇" : command.settings?.limit ? "🥈" : ""}`).join("\n")}
─────────────────────────
`;
            });

            caption += footer;

            m.reply({
                video: {
                    url: config.random.video
                },
                caption,
                gifPlayback: true,
                contextInfo: {
                    mentionedJid: Belle.parseMention(caption),
                    externalAdReply: {
                        title: "© " + config.name + " | Playground",
                        body: "🖤Cursed Puppet and Puppeteer✂️",
                        mediaType: 1,
                        sourceUrl: config.link.channel,
                        thumbnailUrl: config.random.thumbnail,
                        mediaUrl: config.link.youtube, // gantinya di configuration.js
                        renderLargerThumbnail: true,
                    },
                },
            });
        } else if (Object.keys(menu).find((a) => a === text.toLowerCase())) {
            let list = menu[Object.keys(menu).find((a) => a === text.toLowerCase())];
            let caption = `${header}
「利用者」*Info Pengguna*:
> - 「名」Nama: ${m.pushName}
> - 「タグ」Tag: @${m.sender.split("@")[0]}
> - 「状態」Status: ${m.isOwner ? "Developer" : premium ? "Premium" : "Gratis"}
> - 「制限」Limit: ${m.isOwner ? "Unlimited" : limit}

「機械」*Info Bot*:
> - 「名」Nama: ${pkg.name}
> - 「版」Versi: v${pkg.version}
> - 「稼働」Waktu Aktif: ${Func.toDate(process.uptime() * 1000)}
> - 「接頭」Prefix: [ ${m.prefix} ]
> - 「命令」Total perintah: ${cmd + alias + matches.length}

「時間」*Info Waktu*:
> - 「時」${moment().tz("Asia/Jakarta").format("HH:mm:ss")} WIB
> - 「時」${moment().tz("Asia/Makassar").format("HH:mm:ss")} WITA
> - 「時」${moment().tz("Asia/Jayapura").format("HH:mm:ss")} WIT
> - 「日」Hari: ${["Minggu（日）","Senin（月）","Selasa（火）", "Rabu（水）", "Kamis（木）", "Jumat（金）", "Sabtu（土）"][moment().tz("Asia/Jakarta").day()]}
> - 「日」Tanggal: ${moment().tz("Asia/Jakarta").date()} ${["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"][moment().tz("Asia/Jakarta").month()]} ${moment().tz("Asia/Jakarta").year()}

─────────────────────────
🛠️ *Menu – ${text.toUpperCase()}*
${list.command
  .map(
    (a, i) =>
      `> *(${i + 1})* ${m.prefix + a.name} ${a.settings?.premium ? "🥇" : a.settings?.limit ? "🥈" : ""}`,
  )
  .join("\n")}
─────────────────────────
`;

            caption += footer;

            m.reply({
                video: {
                    url: config.random.video
                },
                caption,
                gifPlayback: true,
                contextInfo: {
                    mentionedJid: Belle.parseMention(caption),
                    externalAdReply: {
                        title: "© " + config.name + " | Playground",
                        body: "🖤Cursed Puppet and Puppeteer✂️",
                        mediaType: 1,
                        sourceUrl: config.link.channel,
                        thumbnailUrl: config.random.thumbnail,
                        mediaUrl: config.link.youtube, // gantinya di configuration.js
                        renderLargerThumbnail: true,
                    },
                },
            });
        } else {
            let list = Object.keys(menu);
            let caption = `${header}
「利用者」*Info Pengguna*:
> - 「名」Nama: ${m.pushName}
> - 「タグ」Tag: @${m.sender.split("@")[0]}
> - 「状態」Status: ${m.isOwner ? "Developer" : premium ? "Premium" : "Gratis"}
> - 「制限」Limit: ${m.isOwner ? "Unlimited" : limit}

「機械」*Info Bot*:
> - 「名」Nama: ${pkg.name}
> - 「版」Versi: v${pkg.version}
> - 「稼働」Waktu Aktif: ${Func.toDate(process.uptime() * 1000)}
> - 「接頭」Prefix: [ ${m.prefix} ]
> - 「命令」Total perintah: ${cmd + alias + matches.length}

「時間」*Info Waktu*:
> - 「時」${moment().tz("Asia/Jakarta").format("HH:mm:ss")} WIB
> - 「時」${moment().tz("Asia/Makassar").format("HH:mm:ss")} WITA
> - 「時」${moment().tz("Asia/Jayapura").format("HH:mm:ss")} WIT
> - 「日」Hari: ${["Minggu（日）","Senin（月）","Selasa（火）", "Rabu（水）", "Kamis（木）", "Jumat（金）", "Sabtu（土）"][moment().tz("Asia/Jakarta").day()]}
> - 「日」Tanggal: ${moment().tz("Asia/Jakarta").date()} ${["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"][moment().tz("Asia/Jakarta").month()]} ${moment().tz("Asia/Jakarta").year()}

─────────────────────────
🗂️ *Daftar Menu*:
> *(all)* ${m.prefix}menu all
${list.map((a) => `> *(${a})* ${m.prefix}menu ${a}`).join("\n")}

─────────────────────────
`;

            caption += footer;

            m.reply({
                video: {
                    url: config.random.video
                },
                caption,
                gifPlayback: true,
                contextInfo: {
                    mentionedJid: Belle.parseMention(caption),
                    externalAdReply: {
                        title: "© " + config.name + " | Playground",
                        body: "🖤Cursed Puppet and Puppeteer✂️",
                        mediaType: 1,
                        sourceUrl: config.link.channel,
                        thumbnailUrl: config.random.thumbnail,
                        mediaUrl: config.link.youtube, // gantinya di configuration.js
                        renderLargerThumbnail: true,
                    },
                },
            });
        }
    },
};