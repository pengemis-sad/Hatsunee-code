/*
 * Nama fitur : Spam NGL
 * Type : Plugin Esm
 * Sumber : https://whatsapp.com/channel/0029Vb6Zs8yEgGfRQWWWp639
 * Author : ZenzzXD
 */

const {
    fetch
} = (...args) => import('node-fetch').then(mod => mod.default(...args))

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

async function spamngl(link, pesan, jumlah) {
    if (!link.startsWith('https://ngl.link/')) throw new Error('Luu ngirim link apa sii 🙄')
    if (!pesan) throw new Error('lu mau ngirim pesan apa?')
    if (isNaN(jumlah) || jumlah < 1) throw new Error('Woilahh jumlah angka minimal lebih dri 0')

    const username = link.split('https://ngl.link/')[1]
    if (!username) throw new Error('eror username tidak ditemukan')

    for (let i = 0; i < jumlah; i++) {
        try {
            await fetch('https://ngl.link/api/submit', {
                method: 'POST',
                headers: {
                    'accept': '*/*',
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: `username=${username}&question=${encodeURIComponent(pesan)}&deviceId=1`
            })
            await delay(1000)
        } catch (err) {
            console.error('gagal kirim : ', err)
        }
    }

    return `Selesai mengirim pesan ke ${username}`
}

// *– 乂 Tipe 2 - Code*

module.exports = {
    command: "spamngl",
    alias: ["spmngl", "nglspam", "nglspammer", "sngl"],
    category: ["tools"],
    settings: {
        limit: true
    },
    description: "spammer ngl link",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        // Lakukan sesuatu di sini
        let [link, jumlahStr, ...pesanArr] = text.split('|')
        let jumlah = parseInt(jumlahStr)
        let pesan = pesanArr.join('|').trim()

        if (!link || !jumlahStr || !pesan) {
            return m.reply(`Contoh : .spamngl https://ngl.link/username|3|wiwokdetok`)
        }

        m.reply('_Wait a second..._')

        try {
            let hasil = await spamngl(link.trim(), pesan, jumlah)
            m.reply(hasil)
        } catch (e) {
            m.reply(`Eror kak : ${e?.message||e}`)
        }
    }
}