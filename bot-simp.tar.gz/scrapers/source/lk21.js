/*Code Skrep lk21
Base : https://tv5.lk21official.cc

Req Dari : Adit nak meletup
Req Ke : 6287701656619


Cara pake :
const lk21 = new LK21()
const search = await lk21.search('Ghost Rider')
const detail = await lk21.detail('https://tv5.lk21official.cc/ghost-rider-2007')
const populer = await lk21.populer(10)

*/
const axios = require('axios');
const cheerio = require('cheerio')

class LK21 {
    constructor() {
        this.baseURL = 'https://tv5.lk21official.cc';
    }

    async getHTML(path) {
        try {
            const res = await axios.get(this.baseURL + path);
            return res.data;
        } catch (e) {
            throw e;
        }
    }

    async search(query) {
        try {
            const html = await this.getHTML('/search.php?s=' + query);
            const $ = cheerio.load(html);
            const result = [];

            $('.search-item').each((i, el) => {
                result.push({
                    title: $(el).find('a[rel="bookmark"]').attr('title').trim(),
                    link: this.baseURL + $(el).find('a[rel="bookmark"]').attr('href'),
                    thumb: $(el).find('img').eq(1).attr('src'),
                    genre: $(el).find('p').eq(0).text().split(':')[1].trim(),
                    country: $(el).find('p').eq(1).text().split(':')[1].trim(),
                    rating: $(el).find('p').eq(2).text().split(':')[1].trim()
                })
            });

            return result;

        } catch (e) {
            throw e
        }
    }

    async detail(url) {
        try {
            const html = await this.getHTML(url.replace(this.baseURL, ''));
            const $ = cheerio.load(html);

            const result = {
                title: $('.img-thumbnail').attr('alt').trim(),
                thumb: 'https:' + $('.img-thumbnail').attr('src'),
                quality: $('.content div:nth-child(1) h3').text(),
                country: $('.content div:nth-child(2) h3').text(),
                main_char: [],
                director: $('.content div:nth-child(4) h3').text(),
                genre: [],
                publishedDate: $('.content div:nth-child(7) h3').text(),
                synopsis: $('blockquote').text().split('Synopsis')[1].trim(),
                duration: $('.content div:nth-child(11) h3').text(),
                player: []
            }

            $('.content div:nth-child(3) h3').each((i, yaw) => result.main_char.push($(yaw).text()))
            $('.content div:nth-child(5) h3').each((i, yaw) => result.genre.push($(yaw).text()))

            $('#loadProviders li').each((i, yaw) => {
                let res = {
                    name: $(yaw).find('a').text(),
                    link: decodeURIComponent($(yaw).find('a').attr('href').split('url=')[1]),
                    quality: []
                }

                $(yaw).find('span').each((my, apala) => {
                    res.quality.push($(apala).text().trim());
                });

                result.player.push(res);

            })

            return result

        } catch (e) {
            throw e
        }
    }
    async populer(page = 1) {
        try {
            const html = await this.getHTML('/populer/page/' + page)
            const $ = cheerio.load(html)
            const result = []

            $('.infscroll-item').each((i, el) => {
                let anunya = {
                    title: $(el).find('.grid-title a').text().trim(),
                    link: $(el).find('.grid-title a').attr('href'),
                    thumb: 'https:' + $(el).find('img').attr('src'),
                    genre: [],
                    rating: $(el).find('.grid-meta .rating').text() || 'unknown',
                    quality: $(el).find('.quality').text(),
                    duration: $(el).find('.duration').text()
                }

                $(el).find('.grid-categories a').each((ii, yaw) => {
                    if ($(yaw).attr('href').includes('/genre/')) {
                        anunya.genre.push($(yaw).text())
                    }
                })

                result.push(anunya);

            })

            return result;

        } catch (e) {
            throw e;
        }
    }
}

module.exports = new LK21;