const NodeID3 = require('node-id3');
const axios = require('axios');
const fs = require('fs');
const fetch = (...args) => import('node-fetch').then(({
    default: fetch
}) => fetch(...args));

async function genmusic(prompt) {
    const h = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://suno.exomlapi.com/'
    };
    const datagen = {
        prompt: prompt,
        title: "",
        style: "",
        customMode: false,
        instrumental: false
    };
    try {
        const resGen = await axios.post(
            'https://suno.exomlapi.com/generate',
            datagen, {
                headers: h
            });
        if (resGen.data.status !==
            'initiated') {
            throw new Error(
                'gagal untuk membuatnya om');
        }
        const taskid = resGen.data.taskId;
        const token = resGen.data.token;
        async function checkstats() {
            const statusData = {
                taskId: taskid,
                token: token
            };
            const statsres = await axios
                .post(
                    'https://suno.exomlapi.com/check-status',
                    statusData, {
                        headers: h
                    });
            if (statsres.data.status ===
                'TEXT_SUCCESS') {
                return statsres.data
                    .results;
            }
            if (statsres.data.status ===
                'error') {
                throw new Error(
                    'membuatnya gagal');
            }
            await new Promise(resolve =>
                setTimeout(resolve, 3000));
            return checkstats();
        }
        return await checkstats();
    } catch (e) {
        throw new Error(`${e.message}`);
    }
}

module.exports = {
    command: "generatemusik",
    alias: ["genmusic", "generatesong", "gsong", "gmusic", "buatmusik"],
    category: ["ai", "tools"],
    settings: {},
    description: "Generate musik dengan cover, title, artist, dan album",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        try {
            m.reply("Lagi bikin lagu, bentar ya... 🎶");
            // Kamu bisa ganti prompt, judul, artist, album, cover sesuai kebutuhan
            if (!m.text) return m.reply("> _Promt nya mana gusy?_")
            const prompt = m.text || "Buatkan lagu EDM-pop energik dengan melodi catchy, vibe emosional, drop upbeat, synth elektronik, tempo 128 BPM, vokal ringan penuh harapan, chorus anthemik mirip 'Take Me Home' dari Cash Cash. Temanya tentang pemerintahan Indonesia yang korup, penuh kritik sosial. Tulis juga lirik bahasa Indonesia yang gaul dan sarkas.";
            const results = await genmusic(prompt);
            const data = Array.isArray(results) ? results : results;
            const audioUrl = data.audio_url || data.url || data.result || results[0].audio_url;
            const judul = data.title || results[0].title;
            const coverUrl = data.image_url || config.random.reply || results[0].image_url;
            const filename = Date.now() + '_' + Math.floor(Math.random() * 1000) + '.mp3';

            // Data meta
            const artis = "Artificial intelligence 「光 RenitaBelle—」";
            const album = "Mamorybelle-Album";

            // Download file audio
            const audioRes = await fetch(audioUrl);
            const audioBuffer = await audioRes.buffer();
            fs.writeFileSync(filename, audioBuffer);

            // Download cover image
            const coverRes = await fetch(coverUrl);
            const coverBuffer = await coverRes.buffer();

            // Tambah metadata
            const tags = {
                title: judul,
                artist: artis,
                album: album,
                APIC: coverBuffer
            };
            NodeID3.write(tags, filename);

            // Kirim file ke user
            await m.reply({
                audio: fs.readFileSync(filename),
                fileName: filename,
                mimetype: 'audio/mpeg'
            });
            fs.unlinkSync(filename);
        } catch (e) {
            m.reply(`Gagal: ${e.message}`);
        }
    },
};