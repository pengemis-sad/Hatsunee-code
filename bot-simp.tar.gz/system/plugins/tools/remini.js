const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports = {
    command: "hd",
    alias: ["upscale", "remini", "tohd"],
    category: ["tools"],
    settings: {},
    description: "hdkan img pake scraper",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        store,
        text,
        config
    }) {
        // Lakukan sesuatu di sini
        let q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || '';
        if (!/image/.test(mime)) return m.reply(`Kirim atau reply foto dengan caption *${usedPrefix + command}*`);

        try {
            await Belle.sendMessage(m.cht, {
                react: {
                    text: "♻️",
                    key: m.key
                }
            });

            const media = await q.download();
            if (!media) throw 'Gagal mendownload gambar';

            await Belle.sendMessage(m.cht, {
                react: {
                    text: "⚡",
                    key: m.key
                }
            });

            const filePath = `./tmp/image-${Date.now()}.jpg`;
            await fs.writeFileSync(filePath, media);

            const url = await upscale(filePath);

            const bufferHD = await (await axios.get(url.result.imageUrl, {
                responseType: 'arraybuffer'
            }).catch(e => e.response)).data;

            await Belle.sendMessage(m.cht, {
                image: bufferHD,
                caption: `✅ Berhasil di-HD-kan!\n\n📁 *HD PHOTO*\n> • Ukuran: ${url.result.size || '-'}`
            }, {
                quoted: m
            });

            await Belle.sendMessage(m.cht, {
                react: {
                    text: "✅",
                    key: m.key
                }
            });

            fs.unlinkSync(filePath);
        } catch (e) {
            console.error('Error:', e);

            await Belle.sendMessage(m.cht, {
                react: {
                    text: "❌",
                    key: m.key
                }
            });

            await m.reply('❌ Terjadi kesalahan, coba lagi nanti. Mungkin server sedang sibuk.');
        }
    },
};

async function upscale(filePath) {
    const buffer = fs.readFileSync(filePath);
    const ext = path.extname(filePath).slice(1) || 'bin';
    const mime = ext === 'png' ? 'image/png' : ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' : 'application/octet-stream';
    const fileName = Math.random().toString(36).slice(2, 8) + '.' + ext;

    const {
        data
    } = await axios.post("https://pxpic.com/getSignedUrl", {
        folder: "uploads",
        fileName
    }, {
        headers: {
            "Content-Type": "application/json"
        }
    });

    await axios.put(data.presignedUrl, buffer, {
        headers: {
            "Content-Type": mime
        }
    });

    const fileUrl = "https://files.fotoenhancer.com/uploads/" + fileName;

    const api = await (await axios.post("https://pxpic.com/callAiFunction", new URLSearchParams({
        imageUrl: fileUrl,
        targetFormat: 'png',
        needCompress: 'no',
        imageQuality: '100',
        compressLevel: '6',
        fileOriginalExtension: 'png',
        aiFunction: 'upscale',
        upscalingLevel: ''
    }).toString(), {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'accept-language': 'id-ID'
        }
    }).catch(e => e.response)).data;

    const formatSize = size => {
        const round = (value, precision = 1) => Math.round(value * Math.pow(10, precision)) / Math.pow(10, precision);
        const KB = 1024,
            MB = KB * KB,
            GB = KB * MB;
        if (size < KB) return size + "B";
        if (size < MB) return round(size / KB) + "KB";
        if (size < GB) return round(size / MB) + "MB";
        return round(size / GB) + "GB";
    };

    const buffersize = await (await axios.get(api.resultImageUrl, {
        responseType: 'arraybuffer'
    }).catch(e => e.response)).data;

    const size = formatSize(buffer.length);

    return {
        status: 200,
        success: true,
        result: {
            size,
            imageUrl: api.resultImageUrl
        }
    };
}