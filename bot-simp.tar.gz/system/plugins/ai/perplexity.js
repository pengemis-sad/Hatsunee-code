/*
 * Nama fitur : Perplexity AI Realtime
 * Type : Plugin Esm
 * Sumber : https://whatsapp.com/channel/0029Vb6Zs8yEgGfRQWWWp639
 * Author : ZenzzXD
 */
const axios = require('axios');
const {
    v4: uuidv4
} = require('uuid');
const fs = require('fs');
const dbPath = './library/database/perplexity-db.json';

const ANDROID_ID = '0a0000000002f59a'

const perplexity = {
    handleSSE: function(response) {
        return new Promise((resolve, reject) => {
            let finalData = null
            let buffer = ''

            response.data.on('data', (chunk) => {
                buffer += chunk.toString()
                const lines = buffer.split('\n')
                buffer = lines.pop() || ''

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const jsonData = line.substring(6).trim()
                            if (jsonData === '{}') continue
                            const data = JSON.parse(jsonData)
                            if (data.final === true || data.status === 'COMPLETED') {
                                finalData = data
                            }
                        } catch (e) {
                            continue
                        }
                    }
                }
            })

            response.data.on('end', () => {
                let fullAnswer = ''
                let chunks = []
                let parsedSteps = []
                let webResults = []

                if (finalData && finalData.blocks) {
                    const markdownBlock = finalData.blocks.find(
                        block => block.intended_usage === 'ask_text' && block.markdown_block
                    )

                    if (markdownBlock && markdownBlock.markdown_block) {
                        if (markdownBlock.markdown_block.answer) {
                            fullAnswer = markdownBlock.markdown_block.answer
                        } else if (markdownBlock.markdown_block.chunks) {
                            chunks = markdownBlock.markdown_block.chunks
                            fullAnswer = chunks.join('')
                        }
                    }
                }

                try {
                    parsedSteps = JSON.parse(finalData.text)
                    const step = parsedSteps.find(step => step.step_type === 'SEARCH_RESULTS')
                    if (step?.content?.web_results) {
                        webResults = step.content.web_results
                    }
                } catch (e) {}

                resolve({
                    answer: fullAnswer,
                    chunks,
                    relatedQueries: finalData?.related_queries || [],
                    source: webResults
                })
            })

            response.data.on('error', reject)
        })
    },

    chat: async function(query) {
        const data = JSON.stringify({
            query_str: query,
            params: {
                source: 'android',
                version: '2.17',
                frontend_uuid: uuidv4(),
                android_device_id: ANDROID_ID,
                mode: 'concise',
                is_related_query: false,
                is_voice_to_voice: false,
                timezone: 'Asia/Shanghai',
                language: 'in',
                query_source: 'home',
                is_incognito: false,
                use_schematized_api: true,
                send_back_text_in_streaming_api: false,
                supported_block_use_cases: [
                    'answer_modes', 'finance_widgets', 'knowledge_cards',
                    'media_items', 'place_widgets', 'shopping_widgets',
                    'sports_widgets', 'inline_entity_cards', 'inline_images',
                    'inline_assets', 'search_result_widgets'
                ],
                sources: ['web'],
                model_preference: 'turbo'
            }
        })

        const config = {
            method: 'POST',
            url: 'https://www.perplexity.ai/rest/sse/perplexity_ask',
            headers: {
                'User-Agent': 'Ask/2.51.0/260466 (Android; Version 12; SAMSUNG N900A/SD1A.210817.037.A1 release-keys) SDK 31',
                'Accept': 'text/event-stream',
                'Accept-Encoding': 'gzip',
                'Content-Type': 'application/json',
                'x-app-version': '2.51.0',
                'x-client-version': '2.51.0',
                'x-client-name': 'Perplexity-Android',
                'x-client-env': 'prod',
                'x-app-apiclient': 'android',
                'x-app-apiversion': '2.17',
                'accept-language': 'id',
                'x-device-id': `android:${ANDROID_ID}`,
                'content-type': 'application/json; charset=utf-8'
            },
            data,
            responseType: 'stream'
        }

        const response = await axios.request(config)
        const result = await this.handleSSE(response)
        return result
    }
}

function loadDB() {
    if (!fs.existsSync(dbPath)) return {};
    return JSON.parse(fs.readFileSync(dbPath));
}

function saveDB(db) {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
}

module.exports = {
    command: "perplexity",
    alias: ['pxity', 'perxity', 'xityai'],
    category: ["ai"],
    settings: {},
    description: "ai ril tem ygy",
    loading: false,
    async run(m, {
        text
    }) {
        if (!text) throw `Masukkin pertanyaan, Contoh:.perplexity Skor indonesia vs vietnam U23`

        // --- Session logic START ---
        let db = loadDB();
        let userId = m.sender;

        // Reset manual --newchat
        if (text.includes('--newchat')) {
            db[userId] = {
                count: 0
            };
            saveDB(db);
            return m.reply('Sesi chat baru, counter di-reset!');
        }

        // Init dan limit otomatis
        if (!db[userId]) db[userId] = {
            count: 0
        };
        if (db[userId].count >= 20) {
            db[userId].count = 0;
            saveDB(db);
            return m.reply('Limit 20x command! Counter di-reset, silakan mulai lagi.');
        }

        db[userId].count += 1;
        saveDB(db);
        // --- Session logic END ---

        await m.react('🤔');
        try {
            let res = await perplexity.chat(text);
            let hasil = res.answer || 'gada jawaban dari ai nya bre';
            m.reply(hasil);
        } catch (e) {
            m.reply(`Eror kak: ${e.message}`);
        }
    }
}