const color = require("chalk");

module.exports = (m) => {
    const tag = color.green.bold("【ワッツアップ】");
    const divider = color.magenta.bold("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    let info = `\n${tag} ${color.cyan.bold("「メッセージ しんきゅう」")}\n`;
    info += `${divider}\n`;
    info += color.white.bold("「チャットのしゅるい」: ") + 
            color.green.bold(m.isGroup? "グループ": "プライベート") + "\n";

    if (m.isGroup) {
        info += color.white.bold("「グループめい」: ") + color.yellow.bold(m.metadata.subject) + "\n";
    }

    info += color.white.bold("「タイプ」: ") + color.blue.bold(m.type) + "\n";
    info += color.white.bold("「なまえ」: ") + color.magenta.bold(m.pushName) + "\n";
    info += `${divider}\n`;

    const body = m.body? color.bgBlue.white.bold(` 「メッセージ」: ${m.body} `): color.bgBlue.white.bold(` 「ファイル/メディア」 `);

    info += `${body}\n`;
    info += `${divider}\n`;

    console.log(info);
};