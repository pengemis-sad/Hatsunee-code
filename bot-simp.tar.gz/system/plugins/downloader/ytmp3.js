const yts = require("yt-search");
const axios = require("axios");

module.exports = {
    command: "play",
    alias: ["play", "yta"],
    category: ["downloader"],
    settings: {
        limit: true,
    },
    description: "Cari dan unduh audio dari YouTube / YouTubeの音声をダウンロード",
    async run(m, {
        Belle,
        Func,
        text,
        config
    }) {
        async function playYt(judul) {
            try {
                const query = await yts(judul);
                const res = await axios.post('https://e.ecoe.cc/?_=' + Math.random(), {
                    url: query.all[0].url
                });

                return {
                    thumb: query.all[0].thumbnail,
                    title: res.data.title,
                    link: res.data.url,
                    url: query.all[0].url
                };
            } catch (e) {
                return await ytmp3(judul);
            }
        }

        async function ytmp3(text) {
            const query = (await yts(text)).all[0];
            const URL = query.url;
            const headers = {
                "accept": "*/*",
                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
                "sec-ch-ua-mobile": "?1",
                "sec-ch-ua-platform": "\"Android\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "cross-site",
                "Referer": "https://id.ytmp3.mobi/",
                "Referrer-Policy": "strict-origin-when-cross-origin"
            }

            const initial = await axios.get(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {
                headers
            });
            const format = 'mp3';
            const init = initial.data;

            const id = URL.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
            if (!id) throw "Link YouTube tidak valid.";

            const convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
            const converts = await axios.get(convertURL, {
                headers
            });
            const convert = converts.data;

            let info = {};
            for (let i = 0; i < 3; i++) {
                const j = await axios.get(convert.progressURL, {
                    headers
                });
                info = j.data;
                if (info.progress == 3) break;
                await new Promise(res => setTimeout(res, 1000)); // kasih delay
            }

            const b = (await axios.get(convert.downloadURL, {
                responseType: 'arraybuffer'
            })).data
            const Buf = Buffer.from(b);
            const Buff = await Func.toMp3(Buf)

            return {
                url: convert.downloadURL,
                title: info.title,
                thumb: query.thumbnail,
                link: URL,
                buffer: Buff
            };
        }


        if (!text) {
            return m.reply(
                `╭──[❌ *Masukkan Input yang Valid / 有効な入力を入力してください* ]
᎒⊸ Ketik teks untuk mencari video YouTube, atau masukkan link YouTube yang valid.
᎒⊸ Contoh: *${m.prefix}play Lathi* atau *${m.prefix}play https://youtu.be/abc123*
╰────────────•`,
            );
        }

        m.reply(`╭──[⏳ *Sedang Diproses / 処理中* ]
᎒⊸ *Mohon tunggu sebentar... / 少々お待ちください...*
╰────────────•`);

        let hasil = await playYt(text);

        if (!hasil || !hasil.link) {
            return m.reply(
                `╭──[❌ *Hasil Tidak Ditemukan / 見つかりません* ]
᎒⊸ Tidak ada video ditemukan dengan kata kunci *"${text}"*. Coba gunakan kata kunci lain!
╰────────────•`,
            );
        } else if (!hasil.buffer) {
            Belle.sendMessage(
                m.cht, {
                    audio: {
                        url: hasil.link
                    },
                    mimetype: "audio/mpeg",
                    fileName: hasil.title + ".mp3",
                    contextInfo: {
                        externalAdReply: {
                            sourceUrl: hasil.thumb,
                            mediaUrl: hasil.url,
                            mediaType: 2,
                            description: "音楽を楽しんでください！", // Nikmati musiknya!
                            title: hasil.title,
                            body: config.name,
                            thumbnailUrl: hasil.thumb
                        }
                    }
                }, {
                    quoted: m
                }
            );
        } else {
            Belle.sendMessage(
                m.cht, {
                    audio: hasil.buffer,
                    mimetype: "audio/mpeg",
                    fileName: (hasil.title || "audio") + ".mp3",
                    contextInfo: {
                        externalAdReply: {
                            sourceUrl: hasil.link,
                            mediaUrl: hasil.link,
                            mediaType: 2,
                            title: hasil.title,
                            body: config.name,
                            thumbnailUrl: hasil.thumb
                        }
                    }
                }, {
                    quoted: m
                }
            );
        }
    },
};