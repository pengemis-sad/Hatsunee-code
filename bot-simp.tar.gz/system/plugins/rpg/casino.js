module.exports = {
    command: "casino",
    alias: ["judi"],
    category: ["rpg"],
    settings: {
        group: true
    },
    async run(m, {
        Belle,
        args
    }) {
        try {
            if (args.length < 1) return m.reply('casino @user <jumlah>');
            let mention = m.quoted ?
                m.quoted.sender :
                m.mentions.length > 0 ?
                m.mentions[0] :
                false;
            if (!mention) return m.reply('Tag lawan kamu!');
            let playerA = m.sender;
            let playerB = mention;
            let bet = parseInt(args);
            if (isNaN(bet) || bet < 1) return m.reply('Jumlah taruhan tidak valid!');
            if (db.list().user[playerA].rpg.money < bet) return m.reply('Saldo kamu kurang!');
            if (db.list().user[playerB].rpg.money < bet) return m.reply('Saldo lawan kurang!');
            m.reply(`@${playerB.split("@")[0]}, ketik *terima* untuk menerima tantangan casino dari @${playerA.split('@')[0]} sebesar ${bet} uang!`, {
                mentions: [playerB]
            });
            Belle.casino = Belle.casino || {};
            Belle.casino[playerB] = {
                playerA,
                bet,
                chat: m.cht
            };
        } catch (e) {
            m.reply('Terjadi error:\n' + e.toString());
        }
    }
};
