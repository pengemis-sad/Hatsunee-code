const axios = require('axios');
const crypto = require('crypto');
const FormData = require('form-data');

// Fungsi enkripsi data timestamp
function cyphereddata(t, r = "cryptoJS") {
    t = t.toString();
    const e = crypto.randomBytes(32); // salt
    const a = crypto.randomBytes(16); // iv
    const i = crypto.pbkdf2Sync(r, e, 999, 32, 'sha512'); // key derivation
    const cipher = crypto.createCipheriv('aes-256-cbc', i, a);
    let encrypted = cipher.update(t, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return JSON.stringify({
        amtext: encrypted,
        slam_ltol: e.toString('hex'),
        iavmol: a.toString('hex')
    });
}

// Fungsi untuk mengirim audio ke API noise removal
const NoiseRemover = {
    async run(buffer) {
        const timestamp = Math.floor(Date.now() / 1000);
        const encryptedData = JSON.parse(cyphereddata(timestamp));

        const formData = new FormData();
        formData.append('media', buffer, {
            filename: crypto.randomBytes(3).toString('hex') + '_halo.mp3'
        });
        formData.append('fingerprint', crypto.randomBytes(16).toString('hex'));
        formData.append('mode', 'pulse');
        formData.append('amtext', encryptedData.amtext);
        formData.append('iavmol', encryptedData.iavmol);
        formData.append('slam_ltol', encryptedData.slam_ltol);

        const response = await axios.post(
            'https://noiseremoval.net/wp-content/plugins/audioenhancer/requests/noiseremoval/noiseremovallimited.php',
            formData, {
                headers: {
                    ...formData.getHeaders(),
                    "accept": "*/*",
                    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                    "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
                    "sec-ch-ua-mobile": "?1",
                    "sec-ch-ua-platform": "\"Android\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin",
                    "x-requested-with": "XMLHttpRequest",
                    "Referer": "https://noiseremoval.net/",
                    "Referrer-Policy": "strict-origin-when-cross-origin"
                },
            }
        );

        return response.data;
    },
};

// Handler untuk WhatsApp bot
module.exports = {
    command: "noiseless",
    alias: ["noise", "clearnoise", "nl"],
    category: ["tools"],
    settings: {},
    description: "menghilangkan noise pada audio ",
    loading: true,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config
    }) {
        // Lakukan sesuatu di sini
        // Cek apakah media adalah audio
        if (m.quoted.type !== "audioMessage")
            return m.reply("Media audionya mana?");
        try {
            const buffer = await m.quoted.download();
            const result = await NoiseRemover.run(buffer);

            const audioUrl = result?.media?.enhanced?.uri;
            if (!audioUrl)
                return m.reply("Gagal mendapatkan file hasil.");

            await Belle.sendMessage(m.cht, {
                audio: {
                    url: audioUrl
                },
                mimetype: "audio/mp4"
            });

        } catch (error) {
            console.error("NoiseRemover error:", error.response?.data || error.message || error);
            await m.reply("Terjadi error saat proses noise removal.");
        };
    },
};