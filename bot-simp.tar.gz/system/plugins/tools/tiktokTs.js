module.exports = {
    command: "tiktoktranscript",
    alias: ["tttraskrip", "tttranscript", "tiktokts", "traskriptt"],
    category: ["tools"],
    settings: {},
    description: "",
    loading: false,
    async run(m, {
        Belle,
        Func,
        Scraper,
        Uploader,
        coreWaData,
        text,
        config,
        args
    }) {
        try {
            if (!m.args[0]) return m.reply('Masukkan Link Tiktoknya')

            const result = await Scraper.tiktokTs(m.args[0])

            await m.reply(`${result.text}`)
        } catch (e) {
            m.reply(e.message)
        }
    }
}