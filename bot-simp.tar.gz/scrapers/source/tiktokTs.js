const axios = require('axios');

const TtTranscript = async (videoUrl) => {
    const res = await axios.post(
        'https://www.short.ai/self-api/v2/project/get-tiktok-youtube-link', {
            link: videoUrl
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Origin': 'https://www.short.ai',
                'Referer': 'https://www.short.ai/tiktok-script-generator',
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'
            }
        }
    )

    const data = res.data?.data?.data
    if (!data) throw new Error('No transcript data found')

    return {
        text: data.text,
        duration: data.duration,
        language: data.language,
        url: res.data?.data?.url,
        segments: data.segments.map(s => ({
            start: s.start,
            end: s.end,
            text: s.text
        }))
    }
}

module.exports = TtTranscript;