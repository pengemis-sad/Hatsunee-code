const fs = require('fs');
const path = './library/database/store.json';

const coreWaData = () => {
  const data = {
    contacts: {},
    chats: {},
    messages: {},
    groupMetadata: {}
  };

  return {
    bind: (Belle) => {
      // Custom binding (optional)
    },
    loadMessage: async (jid, id) => {
      if (data.messages[jid] && data.messages[jid][id]) return data.messages[jid][id];
      return undefined;
    },
    writeToFile: (filePath = path) => {
      try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
      } catch (e) {
        console.error('Failed to save store data:', e);
      }
    },
    readFromFile: (filePath = path) => {
      try {
        if (fs.existsSync(filePath)) {
          const fileData = fs.readFileSync(filePath, 'utf-8');
          const parsed = JSON.parse(fileData);
          data.contacts = parsed.contacts || {};
          data.chats = parsed.chats || {};
          data.messages = parsed.messages || {};
          data.groupMetadata = parsed.groupMetadata || {};
        }
      } catch (e) {
        console.error('Failed to load store data:', e);
      }
    },
    data
  };
};

module.exports = coreWaData;