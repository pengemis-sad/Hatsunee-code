const fs = require("fs");
const thumb = require('@library/database/thumb.json');

const config = {
  owner: ["6285786361889", "62882006233840", "6288975063916"],
    ownerLid: ["172374536274067@lid"],
  botNumber: "6288975063916",
  reportNum: '62882006233840',
  name: "光 RenitaBelle—",
  author: "控 GrizLy nyasar—",
  sessions: "memorybelle",
  prefix: ["!", ".", "#", "/"], // Tambahkan prefix sesuai kebutuhan
  tz: "Asia/Jakarta",
  database: "belle-memory", 
  inviteCode: "GDbGX3ClliwIblN7AN2PTM",
  paircode: "MARYBELE",
  
  id: {
    group: "1@g.us",
    newsletter: "120363415055903622@newsletter",
  },
  
  style: {
    bold: (text) => `*${text}*`,
    italic: (text) => `_${text}_`,
    strikethrough: (text) => `~${text}~`,
    monospace: (text) => `\`\`\`${text}\`\`\``,
    boldItalic: (text) => `_*${text}*_`,
    boldUnderline: (text) => `**_${text}_**`,
    quote: (text) => `> ${text}`,
    bullet: (text) => `• ${text}`,
    number: (num, text) => `${num}. ${text}`
  },
  
  link: {
    channel: "https://whatsapp.com/channel/0029VbADFlR3mFXzAtoGGe3S",
    group: "https://chat.whatsapp.com/GDbGX3ClliwIblN7AN2PTM",
    github: "-",
    tiktok: "-",
    douyin: "-",
    youtube: "-",
    facebook: "-",
    x: "-",
    discord: "-",
    telegram: "-"
  },
  
  random: {
    get thumbnail() {
      return thumb.menuThumb[Math.floor(Math.random() * thumb.menuThumb.length)];
    },
    get reply() {
      return thumb.menuUrl[Math.floor(Math.random() * thumb.menuUrl.length)];
    },
    get video() {
      return thumb.menuVideo[Math.floor(Math.random() * thumb.menuVideo.length)];
    },
      get audio() {
      return thumb.menuAudio[Math.floor(Math.random() * thumb.menuVideo.length)];
    },
  },

  settings: {
    antiCall: true,
    autoFollowNewsletter: false,
    autoGoodbye: true,
    autoJoinGc: true,
    autoTyping: false,
    autoWelcome: true,
    dmOnly: false,
    groupOnly: false,
    online: true,
    readChat: false,
    readSw: true,
    reactSw: true,
    statusOnly: false,
  },

  messages: {
    call: "> 🚫 *Mohon maaf*... Kami tidak bisa menerima telepon dari Anda, anti call aktif!",
    unregistered: "> ❎ *Mohon maaf*... Anda belum terdaftar dalam database kami, silahkan daftar agar Anda dapat menggunakan fitur ini.\n\n> Ketik .daftar [nama Anda] agar Anda terdaftar.",    
    wait: "> ⏳ *Mohon tunggu sebentar*... Kami sedang memproses permintaan Anda, harap bersabar ya!", 
    maintenance: "> 🚧 *Fitur sedang dalam pemeliharaan*... Mohon tunggu hingga perbaikan selesai.",
    owner: "> 🧑‍💻 *Fitur ini hanya untuk pemilik bot*... Maaf, Anda tidak memiliki akses ke fitur ini.", 
    admin: "> 👮 *Fitur ini hanya untuk Admin Grup*... Pastikan Anda adalah admin untuk menggunakannya.",
    botAdmin: "> ⚠️ *Bot harus menjadi admin grup*... Berikan hak admin kepada bot untuk menggunakan fitur ini.", 
    group: "> 👥 *Fitur ini hanya tersedia di grup*... Pastikan Anda berada di grup WhatsApp untuk mengakses fitur ini.",
    private: "> 🔒 *Fitur ini hanya tersedia di chat pribadi*... Gunakan di chat pribadi dengan bot.",
    premium: "> 🥇 *Upgrade ke Premium* untuk mendapatkan akses ke fitur eksklusif, murah dan cepat! Hubungi admin untuk info lebih lanjut.", 
    error: "> ❌ *Terjadi kesalahan*... Silakan laporkan kepada pemilik bot untuk diperbaiki.",
    errorlink: "> 🔗 *Harap masukkan URL yang valid*... URL harus dimulai dengan 'https://'.",
    success: "> ✅ *Berhasil!*... Permintaan Anda telah diproses dengan sukses.",
    done: "> 🎉 *Selesai!*... Terima kasih sudah menggunakan fitur ini!",
    example: "> ❎ *Contoh Penggunaan Fitur*",
    badwords: "> ❎ *Mohon maaf*... Anda tidak diperbolehkan berkata kasar disini, saya akan menghapus pedan anda"
},

  sticker: {
    packname: "\n\n☘️\n\n☘", 
    author: `Nama: 光 RenitaBelle—\nBot: 6288975063916\nOwner: 控 GrizLy nyasar— \nDibuat: ${new Date().toLocaleDateString('id-ID')}`, 
    packId: "https://youtube.com/@RenitaMarybelle",    
    email: "agentgoodman130@gmail.com",
    website: "https://wa.me/6288975063916",
    androidApp: "https://play.google.com/store/apps/details?id=com.bitsmedia.android.muslimpro",
    iOSApp: "https://apps.apple.com/id/app/muslim-pro-al-quran-adzan/id388389451?|=id",
    emojis: ["✨", "🦋", "🌸", "💖", "anggun", "ceria", "manis", "renita", "belle"],
    isAvatar: 0,
  },

  bot: {
    whatsapp: true,
  }, // True = activate, False = turn off
  

};

module.exports = config;

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  delete require.cache[file];
});
