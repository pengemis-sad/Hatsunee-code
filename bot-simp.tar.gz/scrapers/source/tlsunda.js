const axios = require('axios');

const tl = async text => {
    let data = {
        from: "id_ID",
        to: "su_ID",
        text: text,
        platform: "dp"
    }
    const res = await axios.post('https://lingvanex.com/translation/translate', data, {
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        }
    })
    return res.data.result
}

module.exports = tl;